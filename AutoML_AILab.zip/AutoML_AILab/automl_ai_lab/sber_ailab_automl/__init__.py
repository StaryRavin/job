from .lib.automl import AutoML
from .lib.sklearn_wrapper import SAARegressor, SAAClassifier
from .report.reportgenerator import ReportGenerator
__version__ = '1.4.2'
