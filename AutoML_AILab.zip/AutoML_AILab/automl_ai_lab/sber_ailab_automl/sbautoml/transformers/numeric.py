import pandas as pd
from pandas import Series, DataFrame

import numpy as np
from numpy import random
random.seed(999)

import gc

import os


import datetime
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.utils import murmurhash3_32
from sklearn.linear_model import SGDClassifier, SGDRegressor
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.model_selection import StratifiedKFold, KFold, cross_val_predict

from copy import deepcopy



# numeric
class ScalerImputer(TransformerMixin, BaseEstimator):
    
    def __init__(self, nan_rate = 0.03, dtype = np.float32):
        super().__init__()
        self.nan_rate = nan_rate
        self.dtype = dtype
        
        
        
    def fit(self, X, y = None):
        
        self.scales = {}
        self.nans = set()
        for i in X.columns:
            
            stats = {}
            var = X[i].values
            nans = np.isnan(var)
            var = var[nans == False]
            std = var.std()
            if std > 0:      
                stats['mean']   = var.mean()
                stats['std']    = std
                self.scales[i] = stats
            if nans.mean() > self.nan_rate:
                self.nans.add(i)
                
        return self
    
    def transform(self, X, y = None):
        
        if (len(self.scales) + len(self.nans)) == 0:
            self.feature_names = []
            return np.array([[] for x in range(X.shape[0])], dtype = self.dtype)
        else:

            res = DataFrame(index = X.index)

            for i in X.columns:
                if i in self.scales:
                    scl = self.scales[i]
                    res[i] = ((X[i] - scl['mean']) / scl['std']).fillna(0).astype(self.dtype)
                if i in self.nans:
                    res[i + '_isnan'] = X[i].isnull().astype(self.dtype)

            self.feature_names = list(res.columns)
            return res

    def get_feature_names(self):
        
        return self.feature_names
