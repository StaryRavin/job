import pandas as pd
from pandas import Series, DataFrame

import numpy as np
from numpy import random
random.seed(999)

import gc

import os


import datetime
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.utils import murmurhash3_32
from sklearn.linear_model import SGDClassifier, SGDRegressor
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.model_selection import StratifiedKFold, KFold, cross_val_predict
from scipy import sparse

from copy import deepcopy



class LabelEncoder(TransformerMixin, BaseEstimator):
    
    def __init__(self, co = 1, subs = 1000, random_state = 42, dtype = np.float32):
        
        self.co = co
        self.subs = subs
        self.random_state = random_state
        self.dtype = dtype
        
    def get_feature_names(self):
        return self.feature_names
        
    def fit(self, X, y = None):
        
        if X.shape[0] >= self.subs:
            subs = X.sample(n = self.subs, axis = 0, random_state = self.random_state)
        else:
            subs = X
        
        self.dicts = {}
        for i in subs.columns:
            cnts = subs[i].value_counts(dropna = False)
            vals = cnts[cnts > self.co].index.values
            self.dicts[i] = Series(np.arange(vals.shape[0], dtype = np.float32) + 1, index = vals)
        return self
            
    def transform(self, X):
        
        res = DataFrame(index = X.index)
        self.feature_names = list(X.columns)
        
        
        for i in X.columns:
            res[i] = X[i].map(self.dicts[i]).fillna(0).astype(self.dtype)

        return res
        
    
######################################
# target encoding

######################################
class HashMeanEncoder(TransformerMixin, BaseEstimator):
    
    def __init__(self, name, alpha = 1, use_freqs = True, dtype = np.float32, cv = 5, 
                 random_state = 42, task = 'c', hash_size = None):
        
        self.name = name
        self.alpha = alpha
        self.use_freqs = use_freqs
        self.dtype = dtype
        self.cv = cv
        self.random_state = random_state
        self.task = task
        self.hash_size = hash_size
        
                
    def get_feature_names(self):
        return self.feature_names
    
    
    def get_cv_folds(self, y):
        
        if self.task == 'c':
            folds = StratifiedKFold(self.cv, random_state = self.random_state, shuffle = True)
        else:
            folds = KFold(self.cv, random_state = self.random_state, shuffle = True)
            
        test_folds = np.empty_like(y, dtype = np.uint8)
        
        if self.task == 'c':
            sp = (y, y)
        else:
            sp = (y, )
        
        for n, (f0, f1) in enumerate(folds.split(*sp)):
            test_folds[f1] = n
        
        return test_folds  
    
    
    def fit(self, X, y):

        if type(y) is Series:
            y = y.values
            
        hash_size = self.hash_size
        if hash_size is None:
            hash_size = 2 ** 31 - 1
        else:
            hash_size = int(min(0, max(10, hash_size)))
            
        
        # get hash of input
        hashed_X = np.array(list(map(lambda x: murmurhash3_32(str(x), seed = 42, positive = True), 
                                               X.fillna('NaN').values[:, 0])), dtype = np.int64) % hash_size 
        # make sparse count
        self.count_ = sparse.coo_matrix((np.ones_like(y, dtype = np.uint8), (np.zeros_like(y, dtype = np.uint8), hashed_X)),
                                   dtype = np.float32, shape = (1, hash_size)
                                  ).tolil()
        # make sparse sum
        self.sum_ = sparse.coo_matrix((y, (np.zeros_like(y, dtype = np.uint8), hashed_X)),
                                   dtype = np.float32, shape = (1, hash_size)
                                  ).tolil()
        # calc prior
        self.prior = y.sum() / y.shape[0]
        
        
    def transform(self, X):
        
        hash_size = self.hash_size
        if hash_size is None:
            hash_size = 2 ** 31 - 1
        else:
            hash_size = int(min(0, max(10, hash_size)))
        
        # get hash of input
        hashed_X = np.array(list(map(lambda x: murmurhash3_32(str(x), seed = 42, positive = True), 
                                               X.fillna('NaN').values[:, 0])), dtype = np.int64) % hash_size 
        
        sum_ = self.sum_[:, hashed_X].toarray()[0]
        count_ = self.count_[:, hashed_X].toarray()[0]
        
        # calc result
        res = DataFrame(index = X.index)
        name = self.name
        
        # get mean
        mean_ = np.ones((X.shape[0], ), dtype = self.dtype) * self.prior
        sl = count_ > 0
        mean_[sl] = (sum_[sl] + self.alpha * self.prior) / (count_[sl] + self.alpha)
        res['{0}_{1}'.format(name, 'mean_enc')] = mean_.astype(self.dtype)
        
        # get count
        # res['{0}_{1}'.format(name, 'cnt_enc')] = np.clip(count_, 1, None)   
        
        self.feature_names = res.columns
        return res
    
    def fit_transform(self, X, y):
        res = DataFrame(index = X.index)
        name = self.name
        
        hash_size = self.hash_size
        if hash_size is None:
            hash_size = 2 ** 31 - 1
        else:
            hash_size = int(min(0, max(10, hash_size)))
        
        if type(y) is Series:
            y = y.values
        
        test_folds = self.get_cv_folds(y)
        
        # get hash of input
        hashed_X = np.array(list(map(lambda x: murmurhash3_32(str(x), seed = 42, positive = True), 
                                               X.fillna('NaN').values[:, 0])), dtype = np.int64) % hash_size 
        # make sparse count
        count_ = sparse.coo_matrix((np.ones_like(y, dtype = np.uint8), (test_folds, hashed_X)),
                                   dtype = np.float32, shape = (self.cv, hash_size)
                                  ).tolil()
        # make sparse sum
        sum_ = sparse.coo_matrix((y, (test_folds, hashed_X)),
                                   dtype = np.float32, shape = (self.cv, hash_size)
                                  ).tolil()   
        
        # make prediction for each fold
        mean_ = np.empty_like(y, dtype = np.float32)

        for f in range(self.cv):
            
            # get fold_stats
            folds = [x for x in range(self.cv) if x != f]
            sum_f = sum_[folds[0]]
            count_f = count_[folds[0]]
            for fold in folds[1:]:
                sum_f += sum_[fold]
                count_f += count_[fold]
                
            hashed_X_f = hashed_X[test_folds == f]
            sum_f = sum_f[:, hashed_X_f].toarray()[0]
            count_f = count_f[:, hashed_X_f].toarray()[0]
            
            prior_f = y[test_folds != f].sum() / (test_folds != f).sum()
            
            # predict on fold
            mean_f = np.ones((hashed_X_f.shape[0], ), dtype = self.dtype) * prior_f
            sl = count_f > 0
            mean_f[sl] = (sum_f[sl] + self.alpha * prior_f) / (count_f[sl] + self.alpha)
            mean_[test_folds == f] = mean_f
            
        res['{0}_{1}'.format(name, 'mean_enc')] = mean_.astype(self.dtype)

        self.sum_ = sum_[0]
        self.count_ = count_[0]
        for fold in range(1, self.cv):
            self.sum_ += sum_[fold]
            self.count_ += count_[fold]   
        self.prior = y.sum() / y.shape[0]
        
        # count_= self.count_[:, hashed_X].toarray()[0]
        # res['{0}_{1}'.format(name, 'cnt_enc')] = count_
        
        self.feature_names = res.columns
        
        return res  

def hash_cols(df):
    if df.shape[1] == 1:
        hashed_X = df[df.columns[0]].fillna('_nan_').values
    else:
        hashed_X = np.array(list(map(lambda x: murmurhash3_32(str(x), seed = 42, positive = False), 
                                       df.values)), dtype = np.int32)
    return hashed_X

def hash_cols(df):
    if df.shape[1] == 1:
        hashed_X = df[df.columns[0]].fillna('_nan_').values
    else:
        hashed_X = np.array(list(map(lambda x: murmurhash3_32(str(x), seed = 42, positive = False), 
                                       df.values)), dtype = np.int32)
    return hashed_X

class GroupByEncoder(TransformerMixin, BaseEstimator):

    def __init__(self, by, feat, alpha = 1, dtype = np.float32):

        self.by = by
        self.feat = feat
        self.alpha = alpha
        self.name = feat + '_by_' + '_'.join(by) 
        self.dtype = dtype

    def get_feature_names(self):
        return [self.name]

    def fit(self, X, y = None):

        X['_hash_'] = hash_cols(X[self.by])
        self.grp = X.groupby('_hash_')[self.feat].agg(['sum', 'count'])
        self.prior = X[self.feat].mean()
        return self

    def transform(self, X):

        res = DataFrame(index = X.index)

        X['_hash_'] = hash_cols(X[self.by])
        grp = self.grp + X.groupby('_hash_')[self.feat].agg(['sum', 'count'])
        mean = (grp['sum'] + self.alpha * self.prior) / (grp['count'] + self.alpha)

        res[self.name] = X['_hash_'].map(mean).fillna(self.prior).astype(np.float32)

        return res

    def fit_transform(self, X, y = None):

        X['_hash_'] = hash_cols(X[self.by])
        self.grp = X.groupby('_hash_')[self.feat].agg(['sum', 'count'])
        self.prior = X[self.feat].mean()

        mean = (self.grp['sum'] + self.alpha * self.prior) / (self.grp['count'] + self.alpha)

        #predict
        res = DataFrame(index = X.index)
        res[self.name] = X['_hash_'].map(mean).astype(np.float32)

        return res
    
    
    
class GroupByDateEncoder(TransformerMixin, BaseEstimator):

    def __init__(self, by, date, feat, alpha = 1, dtype = np.float32):

        self.by = by
        self.date = date
        self.feat = feat
        self.alpha = alpha
        self.dtype = dtype

    def get_feature_names(self):
        return self.feature_names

    def fit(self, X, y = None):
        
        self.trf_list = []
        for i in ['day', 'weekday', 'month', 'year']:
            X[self.date + '_' + i] = pd.DatetimeIndex(df['datetime_0']).__getattribute__(i).astype(np.float32)
            self.trf_list.append(GroupByEncoder(by = self.by + [self.date + '_' + i], feat = self.feat,
                                                 alpha = self.alpha, dtype = self.dtype
                                                 ).fit(X))
            
        return self

    def transform(self, X):

        res = []
        for i, trf in zip(['day', 'weekday', 'month', 'year'], self.trf_list):
            X[self.date + '_' + i] = pd.DatetimeIndex(X['datetime_0']).__getattribute__(i).astype(np.float32)
            res.append(trf.transform(X))
            
            
        res = pd.concat(res, axis = 1)
        self.feature_names = list(res.columns)
        return res

    def fit_transform(self, X, y = None):
        
        
        res = []
        self.trf_list = []
        for i in ['day', 'weekday', 'month', 'year']:
            X[self.date + '_' + i] = pd.DatetimeIndex(X['datetime_0']).__getattribute__(i).astype(np.float32)
            trf = GroupByEncoder(by = self.by + [self.date + '_' + i], feat = self.feat,
                                                 alpha = self.alpha, dtype = self.dtype
                                                 )
            res.append(trf.fit_transform(X))
            self.trf_list.append(trf)
            
        res = pd.concat(res, axis = 1)
        self.feature_names = list(res.columns)
        return res
