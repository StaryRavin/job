from sklearn.base import TransformerMixin
from sklearn.feature_extraction import DictVectorizer
import numpy as np
from scipy.linalg import svd
from collections import Counter
from itertools import repeat
from tqdm import tqdm_notebook


class WeightedAverageTransformer(TransformerMixin):
    """
    Sentence embeddings is a weighted average of word embeddings
    """

    def __init__(self, embedding_model, embed_size,
                 weight_type='idf', use_svd=True,
                 alpha=0.001, verbose=False):
        """

        :param embedding_model: word2vec, fasstext, etc... should have dict interface {<word>: <embedding>}
        :param embed_size: size of embedding
        :param weight_type: 'idf' for idf weights, 'sif' for smoothed inverse frequency weights, '1' for all weights are equal
        :param use_svd: substract projection onto first singular vector
        :param alpha: param for sif weights
        :param verbose:
        """
        super(WeightedAverageTransformer, self).__init__()

        if weight_type not in ['sif', 'idf', '1']:
            raise Exception("weights should be one of ['sif', 'idf', '1']")

        self.weight_type = weight_type
        self.alpha = alpha
        self.embedding_model = embedding_model
        self.embed_size = embed_size
        self.use_svd = use_svd
        self.verbose = verbose
        self.weights_ = None
        self.u_ = None

    def get_embedding_(self, sentence):
        result = np.zeros((self.embed_size,))
        for word in sentence:
            if word in self.embedding_model and word in self.weights_:
                result += self.embedding_model[word] * self.weights_[word]

        if len(sentence) > 0:
            result = result / len(sentence)

        return result.reshape(1,-1)

    def fit(self, sentences):

        dict_vec = DictVectorizer()
        occurances = dict_vec.fit_transform([dict(Counter(x)) for x in sentences])

        if self.weight_type == 'idf':
            nd = np.asarray((occurances > 0).sum(axis=0)).ravel()
            idf = np.log1p((occurances.shape[0] + 1) / (nd + 1))
            self.weights_ = dict(zip(dict_vec.feature_names_, idf))

        elif self.weight_type == 'sif':
            nd = np.asarray((occurances > 0).sum(axis=0)).ravel()
            pw = (nd + 1) / (occurances.shape[0] + 1)
            pw = self.alpha / (self.alpha + pw)
            self.weights_ = dict(zip(dict_vec.feature_names_, pw))

        else:
            self.weights_ = dict(zip(dict_vec.feature_names_, repeat(1)))

        if self.use_svd:
            if self.verbose:
                sentences = tqdm_notebook(sentences)
            sentence_embeddings = np.vstack([self.get_embedding_(x) for x in sentences])
            u, _, _ = svd(sentence_embeddings.T, full_matrices=False)
            self.u_ = u[:, 0]

        return self

    def transform(self, sentences):

        sentence_embeddings = np.vstack([self.get_embedding_(x) for x in sentences])

        if self.use_svd:
            proj = (self.u_.reshape(-1, 1) * self.u_.dot(sentence_embeddings.T).reshape(1, -1)).T
            sentence_embeddings = sentence_embeddings - proj

        return sentence_embeddings.astype(np.float32)
