import numpy as np
from torch.utils.data import Dataset


class EmbedDataset(Dataset):
    """
    Pytorch interface
    Class for transforming list of tokens to a list of embeddings
    """
    def __init__(self, sentences, embedding_model, max_length, embed_size):
        """

        :param sentences: list of tokenized sentences
        :param embedding_model: word2vec, fasstext, etc... should have dict interface {<word>: <embedding>}
        :param max_length: max sentence length
        :param embed_size: size of embedding
        """
        self.sentences = sentences
        self.embedding_model = embedding_model
        self.max_length = max_length
        self.embed_size = embed_size

    def __getitem__(self, idx):
        result = np.zeros((self.max_length, self.embed_size))
        length = 0
        for word in self.sentences[idx]:
            if word in self.embedding_model:
                result[length, :] = self.embedding_model[word]
                length += 1
                if length >= self.max_length:
                    break

        if length == 0:
            return result, 1
        return result, length

    def __len__(self):
        return len(self.sentences)
