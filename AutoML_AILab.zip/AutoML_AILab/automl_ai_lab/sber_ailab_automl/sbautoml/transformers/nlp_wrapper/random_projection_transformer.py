from sklearn.base import TransformerMixin
import numpy as np
from tqdm import tqdm
from embed_dataset import EmbedDataset

import torch as tt
import torch.nn as nn
from torch.utils.data import DataLoader


def position_encoding_init(n_pos, embed_size):
    position_enc = np.array([
        [pos / np.power(10000, 2 * (j // 2) / embed_size) for j in range(embed_size)]
        if pos != 0 else np.zeros(embed_size) for pos in range(n_pos)])
    position_enc[1:, 0::2] = np.sin(position_enc[1:, 0::2])
    position_enc[1:, 1::2] = np.cos(position_enc[1:, 1::2])
    return tt.from_numpy(position_enc).float()


class BOREP(nn.Module):

    def __init__(self, embed_size, proj_size, pooling, max_length=200, init='orthogonal', pos_encoding=False):
        super(BOREP, self).__init__()

        self.embed_size = embed_size
        self.proj_size = proj_size
        self.pos_encoding = pos_encoding

        if self.pos_encoding:
            self.pos_code = position_encoding_init(max_length, self.embed_size).view(1, max_length, self.embed_size)

            if tt.cuda.is_available():
                self.pos_code = self.pos_code.cuda()

        if pooling == 'mean':
            self.pooling = lambda x: tt.mean(x, dim=0)
        elif pooling == 'max':
            self.pooling = lambda x: tt.max(x, dim=0)[0]
        elif pooling == 'sum':
            self.pooling = lambda x: tt.sum(x, dim=0)

        self.proj = nn.Linear(self.embed_size, self.proj_size, bias=False)
        if init == "orthogonal":
            nn.init.orthogonal_(self.proj.weight)
        elif init == "normal":
            nn.init.normal_(self.proj.weight, std=0.1)
        elif init == "uniform":
            nn.init.uniform_(self.proj.weight, a=-0.1, b=0.1)
        elif init == "kaiming":
            nn.init.kaiming_uniform_(self.proj.weight)
        elif init == "xavier":
            nn.init.xavier_uniform_(self.proj.weight)

    def forward(self, x, x_length):

        self.eval()
        with tt.no_grad():
            batch_size, batch_max_length = x.size(0), x.size(1)

            if self.pos_encoding:
                x = x + self.pos_code[:,:batch_max_length, :]

            x = x.contiguous().view(batch_size * batch_max_length, -1)
            x = self.proj(x)
            x = x.contiguous().view(batch_size, batch_max_length, -1)

            out = tt.zeros(x.size(0), x.size(2))

            for i in range(out.size(0)):
                out[i] = self.pooling(x[i, :x_length[i]])

        return out.detach().cpu().numpy()


class RandomProjectionTransformer(TransformerMixin):
    """
    Sentence embedding is a global pooling of token embeddings, randomly projected into higher-dimensional space
    """

    def __init__(self, embedding_model, embed_size,
                 proj_size=4096, pooling='mean', init='orthogonal',
                 max_length=200,
                 batch_size=4096, num_workers=10,
                 pos_encoding=False, random_state=42, verbose=False):
        """
        Cuda is used if available. adjust batch_size of your video RAM capacity
        :param embedding_model: word2vec, fasstext, etc... should have dict interface {<word>: <embedding>}
        :param embed_size: size of embedding
        :param proj_size: size of projection. proj_size > embed_size of words
        :param pooling: type of pooling - mean, max or sum
        :param init: init distribution - one of 'orthogonal', 'normal', 'uniform', 'kaiming', 'xavier'
        :param max_length: max sentence length
        :param batch_size:
        :param num_workers: for DataLoader
        :param pos_encoding: use positional encoding for tokens
        :param random_state:
        :param verbose:
        """
        super(RandomProjectionTransformer, self).__init__()

        assert proj_size > embed_size

        if pooling not in ['mean', 'max', 'sum']:
            raise Exception("pooling should be one of ['mean', 'max', 'sum']")

        if init not in ['orthogonal', 'normal', 'uniform', 'kaiming', 'xavier']:
            raise Exception("init should be one of ['orthogonal', 'normal', 'uniform', 'kaiming', 'xavier']")

        self.init = init
        self.pooling = pooling
        self.random_state = random_state
        self.embedding_model = embedding_model
        self.embed_size = embed_size
        self.pos_encoding = pos_encoding
        self.proj_size = proj_size
        self.verbose = verbose
        self.max_length = max_length
        self.num_workers = num_workers
        self.batch_size = batch_size

        tt.manual_seed(random_state)
        np.random.seed(random_state)
        if tt.cuda.is_available():
            tt.cuda.manual_seed(random_state)

        self.model = BOREP(self.embed_size, self.proj_size, self.pooling, self.max_length, self.init, self.pos_encoding)

    def fit(self, X):
        return self

    def transform(self, sentences):

        data = EmbedDataset(sentences, self.embedding_model, self.max_length, self.embed_size)
        loader = DataLoader(data, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers)

        result = []
        if self.verbose:
            loader = tqdm(loader)

        if tt.cuda.is_available():
            self.model = self.model.cuda()
            for batch, lengths in loader:
                embed = self.model(batch.float().cuda(), lengths.cuda())
                result.append(embed.astype(np.float32))
        else:
            for batch, lengths in loader:
                embed = self.model(batch.float(), lengths)
                result.append(embed.astype(np.float32))

        result = np.vstack(result)
        return result
