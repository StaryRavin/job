from .abbreviations import ABBREVIATIONS
import re
from pymystem3 import Mystem
import nltk
from nltk.stem import SnowballStemmer

from multiprocessing import Pool
from functools import partial

def tokenizer_func(arr = [], tokenizer = None):
    return [tokenizer.tokenize(x) for x in arr]

class Tokenizer:
    """
    Class for text normalization and tokenization
    """

    def __init__(self, mystem_path, stopwords=None, postags=True,
                 use_stemmer=False):
        """

        :param mystem_path: path to mystem binary
        :param stopwords: list of stopwords to ban
        :param postags: add PoS tags to words -> only word embeddings can be used
        :param use_stemmer:
        """
        self.mystem = Mystem(mystem_path)
        self.postags = postags

        if stopwords is None:
            self.stopwords = nltk.corpus.stopwords.words('russian')
        else:
            self.stopwords = stopwords
        self.stopwords = set(self.stopwords)

        if use_stemmer:
            self.stemmer = SnowballStemmer('russian', ignore_stopwords= stopwords is None)
        else:
            self.stemmer = None

    def _is_abbr(self, word):
        """
        check if the word is an abbreviation
        """
        return sum(map(lambda x: x.isupper() and x.isalpha(), word)) > 1 and len(word) <= 5

    def _tokenize_sentence(self, snt):
        """
        Convert sentence string to a list of tokens
        :param snt: sentence string
        :return:
        """
        s = re.sub('[^A-Za-zА-Яа-я0-9]+', ' ', snt)
        s = re.sub(r'^\d+\s|\s\d+\s|\s\d+$', ' ', s)

        filtered_s = []
        for w in s.split():

            # ignore numbers
            if w.isdigit():
                pass
            elif w.lower() in ABBREVIATIONS:
                filtered_s.extend(ABBREVIATIONS[w.lower()].split())
            elif self._is_abbr(w):
                filtered_s.append(w)
            #         # ignore short words
            elif len(w) < 2:
                pass
            elif w.isalpha():
                filtered_s.append(w.lower())

        result_s = ' '.join(filtered_s)
        result_s = result_s.replace('не ', 'не')
        result_s = result_s.replace('ни ', 'ни')

        return result_s

    def _tag_mystem(self, text):

        """
        Lemmatization. Code is borrowed from rusvectors preprocessing script
        :param text: list of tokens
        :return: lemmatized list of tokens
        """

        processed = self.mystem.analyze(text)
        tagged = []
        for w in processed:
            try:
                lemma = w["analysis"][0]["lex"].lower().strip()
                pos = w["analysis"][0]["gr"].split(',')[0]
                pos = pos.split('=')[0].strip()

                lemma = lemma.lower()

                if lemma in self.stopwords:
                    pass

                if self.stemmer:
                    lemma = self.stemmer.stem(lemma)

                tagged.append(lemma.lower() + '_' + pos)

            except Exception:

                # for words from different language
                if len(w['text'].strip()) > 0 and w['text'].strip().isalpha():

                    if w['text'] in self.stopwords:
                        pass
                    tagged.append(w['text'] + '_UNK')

        if not self.postags:
            tagged = [t.split('_')[0] for t in tagged]
        return tagged

    def tokenize(self, text):
        """
        Convert string to list of tokens
        :param text: string
        :return:
        """
        text = text.strip()

        text = self._tokenize_sentence(text.strip())
        text = self._tag_mystem(text)

        return text
    
    def tokenize_array(self, text_arr, n_jobs = 4):
        if n_jobs == 1:
            return [self.tokenize(x) for x in text_arr]
        else:
            idx = list(range(0, len(text_arr), len(text_arr) // n_jobs + 1)) + [len(text_arr)]
            
            parts = [text_arr[i: j] for (i, j) in zip(idx[:-1], idx[1:])]
            
            f = partial(tokenizer_func, tokenizer = self)
            with Pool(n_jobs) as p:
                res = p.map(f, parts)
            del f
            
            tokens = res[0]
            for r in res[1:]:
                tokens.extend(r)
            print(len(tokens))
            return tokens
                       


