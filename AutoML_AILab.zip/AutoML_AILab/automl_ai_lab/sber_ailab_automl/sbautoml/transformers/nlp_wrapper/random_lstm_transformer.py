from sklearn.base import TransformerMixin
import numpy as np
from tqdm import tqdm
from .embed_dataset import EmbedDataset

import torch as tt
import torch.nn as nn
from torch.utils.data import DataLoader



def avg_pol(x):
    return tt.mean(x, dim=0)

def max_pool(x):
    return tt.max(x, dim=0)[0]
    
def sum_pool(x):
    return tt.max(x, dim=0)[0]
    


class RandomLSTM(nn.Module):

    def __init__(self, embed_size, hidden_size, pooling, num_layers=1):
        super(RandomLSTM, self).__init__()
        # super().__init__()

        self.lstm = nn.LSTM(embed_size, hidden_size, num_layers=num_layers,
                          bidirectional=True, batch_first=True)

        if pooling == 'mean':
            self.pooling = avg_pol
        elif pooling == 'max':
            self.pooling = max_pool
        elif pooling == 'sum':
            self.pooling = sum_pool

    def forward(self, x, x_length):

        self.eval()
        with tt.no_grad():

            x, _ = self.lstm(x)
            out = tt.zeros(x.size(0), x.size(2))

            for i in range(out.size(0)):
                out[i] = self.pooling(x[i, :x_length[i]])

        return out.detach().cpu().numpy()
    
    
    
class RandomLSTMTransformer(TransformerMixin):
    """
    Sentence embeddings is a global pooling of tokens, passed through random LSTM
    Bidirectional LSTM is used
    """

    def __init__(self, embedding_model, embed_size,
                 hidden_size=256,
                 num_layers=1, max_length=200,
                 batch_size=4096, num_workers=10,
                 pooling='mean', random_state=42, verbose=False):
        """
        Cuda is used if available. adjust batch_size of your video RAM capacity
        :param embedding_model: word2vec, fasstext, etc... should have dict interface {<word>: <embedding>}
        :param embed_size: size of embedding
        :param hidden_size: hidden size of LSTM. So sentence embed size = 2 * hidden_size
        :param num_layers: num_layers of LSTM
        :param max_length: max sentence length in tokens
        :param batch_size:
        :param num_workers: for DataLoader
        :param pooling: pooling type - mean, max or sum
        :param random_state:
        :param verbose:
        """
        super(RandomLSTMTransformer, self).__init__()

        if pooling not in ['mean', 'max', 'sum']:
            raise Exception("pooling should be one of ['mean', 'max', 'sum']")

        self.pooling = pooling
        self.random_state = random_state
        self.embedding_model = embedding_model
        self.embed_size = embed_size
        self.num_layers = num_layers
        self.hidden_size = hidden_size
        self.verbose = verbose
        self.max_length = max_length
        self.batch_size = batch_size
        self.num_workers = num_workers

        tt.manual_seed(random_state)
        np.random.seed(random_state)
        if tt.cuda.is_available():
            tt.cuda.manual_seed(random_state)

        self.model = RandomLSTM(self.embed_size, self.hidden_size, self.pooling, self.num_layers)

    def fit(self, X):
        return self

    def transform(self, sentences):

        data = EmbedDataset(sentences, self.embedding_model, self.max_length, self.embed_size)
        loader = DataLoader(data, batch_size=self.batch_size, shuffle=False, num_workers=self.num_workers)

        result = []
        if self.verbose:
            loader = tqdm(loader)

        if tt.cuda.is_available():
            self.model = self.model.cuda()
            for batch, lengths in loader:
                embed = self.model(batch.float().cuda(), lengths.cuda())
                result.append(embed.astype(np.float32))
        else:
            for batch, lengths in loader:
                embed = self.model(batch.float(), lengths)
                result.append(embed.astype(np.float32))

        result = np.vstack(result)
        return result
