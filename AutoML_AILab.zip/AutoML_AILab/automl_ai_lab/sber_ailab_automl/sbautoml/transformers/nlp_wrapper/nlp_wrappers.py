import gensim
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier

from sklearn.externals import joblib
from sklearn.externals.joblib import Parallel, delayed

import numpy as np

from .weighted_average_transformer import WeightedAverageTransformer
from .random_lstm_transformer import RandomLSTMTransformer
from .text_tokenizer import Tokenizer
# from ..sbautoml.transformers.nlp_wrapper.text_tokenizer import Tokenizer
import torch


from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import StratifiedKFold, KFold, GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.linear_model import SGDRegressor, SGDClassifier
from sklearn.base import TransformerMixin, BaseEstimator
from sklearn.model_selection import cross_val_predict
from sklearn.utils.murmurhash import murmurhash3_32

import os
import subprocess
import platform


if platform.system() == 'Linux':
    model_path = os.path.dirname(__file__)  + r'/mystem'
elif platform.system() == 'Windows':
    model_path = os.path.dirname(__file__)  + r'\mystem.exe'
elif platform.system() == 'Darwin':
    model_path = os.path.dirname(__file__)  + r'/mystem_mac'

def single_text_hash(x):
    numhash = murmurhash3_32(x, seed = 13)
    texthash = str(numhash) if numhash > 0 else 'm' + str(abs(numhash))
    return texthash

def get_textarr_hash(X):

    full_hash = single_text_hash(str(X))
    n = 0
    for text in X:
        if text != '':
            full_hash += '_' + single_text_hash(text)
            n += 1
            if n >=3:
                break

    return full_hash
    
class OneToOneTextTransformer(TransformerMixin, BaseEstimator):
    
    def __init__(self, n_jobs = 1, alpha = 0.0001, min_freq = 5, epochs = 1, task = 'r'):
        self.n_jobs = n_jobs
        self.task = task

        if task == 'r':
            Estimator = SGDRegressor
            def predict(X, estimator):
                return estimator.predict(X)
            loss = 'squared_loss'
        else:
            Estimator = SGDClassifier
            def predict(X, estimator):
                return estimator.predict_proba(X)[:, 1]
            loss = 'log'
            
        self.predict = predict
        
        self.estimator = Estimator(alpha = alpha, max_iter = epochs, loss = loss)
        self.vect = TfidfVectorizer(min_df = min_freq, max_df = 1.0, dtype = np.float32)
        
    def get_feature_names(self):
        return self.names
        
    def fit(self, text_arr, y):
        
        self.names = list(text_arr.columns)
        
        text_arr = text_arr[text_arr.columns[0]].fillna('').astype(str)
        
        X = self.vect.fit_transform(text_arr)
        self.estimator.fit(X, y)
        
        return self
    
    def transform(self, text_arr):
        
        text_arr = text_arr[text_arr.columns[0]].fillna('').astype(str)
        
        X = self.vect.transform(text_arr)
        
        pred = self.predict(X, self.estimator)
        if self.task == 'r':
            pred = pred[:, np.newaxis]
        else:
            pred = pred[:, [0]]
        
        return pred.astype(np.float32)
        
    def fit_transform(self, text_arr, y):
        
        self.names = list(text_arr.columns)
        
        text_arr = text_arr[text_arr.columns[0]].fillna('').astype(str)
        
        X = self.vect.fit_transform(text_arr)
        # oof_pred = np.zeros_like(y)
        
        folds = KFold(5).split(y, y) if self.task == 'r' else StratifiedKFold(5).split(y, y)
        
        oof_pred = cross_val_predict(self.estimator, X, y, cv = folds, n_jobs = self.n_jobs,
                                     method = 'predict' if self.task == 'r' else 'predict_proba')
        if self.task == 'r':
            oof_pred = oof_pred[:, np.newaxis]
        else:
            oof_pred = oof_pred[:, [0]]
        
        self.estimator.fit(X, y)
        return oof_pred.astype(np.float32)
    
    
class AutomlNLPWrap(TransformerMixin, BaseEstimator):
    
    def __init__(self, embed_model = None, n_jobs = 1, 
                 fasttext_params = {'sg': 1, 'size': 100, 'min_count': 5, 'epochs': 3},
                 config = None,
                 # tokenizer = Tokenizer(model_path,  postags=False, use_stemmer=False),
                 # transformer = 'auto'
                
                ):
        
        """
        if embed_model is None:
            self.emb_size = fasttext_params['size']
        else:
            embed_model = gensim.models.FastText.load(embed_model)
            self.emb_size = embed_model.vector_size
        self.embed_model = embed_model            
        """
        if isinstance(embed_model, str):
            try:
                self.embed_model = gensim.models.FastText.load(embed_model)
            except Exception:
                self.embed_model = gensim.models.FastText.load_fasttext_format(embed_model)
        else:
            self.embed_model = embed_model
        self.emb_size = self.embed_model.vector_size
        print('CHECK CACHE DIR IN CONFIG', config['cache_dir'] if 'cache_dir' in config.data else None, config['cache_dir'], config.data['cache_dir'])
        self.config = config# ['cache_dir'] if 'cache_dir' in config.data else None
        
        self.n_jobs = n_jobs
        self.tokenizer = Tokenizer(model_path,  postags=False, use_stemmer=False)
        self.fasttext_params = fasttext_params
        self.fasttext_params['workers'] = n_jobs
        if True:
            if config['use_gpu'] and torch.cuda.is_available():
                
                self.transformer = RandomLSTMTransformer(self.embed_model, embed_size = self.emb_size, batch_size=1024, 
                                      hidden_size=512, max_length=200, verbose=True)
            else:
                self.transformer = WeightedAverageTransformer(self.embed_model, embed_size = self.emb_size,
                                                              weight_type='idf', use_svd=True, verbose=True)
                
        else:
            self.transformer = transformer
            
    def get_feature_names(self):
        return self.names
        
    def fit(self, X, y = None):
        
        print(X.columns)
        
        if isinstance(self.transformer, RandomLSTMTransformer):
            self.names = ['e' + str(x) for x in range(self.transformer.hidden_size * 2)]
        else:
            self.names = ['e' + str(x) for x in range(self.emb_size)]
        
        return self
    
    def fit_transform(self, X, y = None):
        
        self.fit(X, y)
        
        col_name = X.columns[0]
        X = X[col_name].fillna('').astype(str)
        
            
        if self.config['cache_dir'] is not None:
            full_hash = get_textarr_hash(X)
            fname = os.path.join(self.config['cache_dir'], col_name + full_hash + '.pkl')
            if os.path.exists(fname):
                print('Load saved tokenization for', col_name) 
                X = joblib.load(fname)
            else:
                print('Tokenization..')
                X = self.tokenizer.tokenize_array(X, n_jobs = self.n_jobs) 
                joblib.dump(X, fname)
        else:
            X = self.tokenizer.tokenize_array(X, n_jobs = self.n_jobs)   
            
        print('Transforming')

        self.transformer = self.transformer.fit(X)
        X_ = self.transformer.transform(X)
            
        print(X_.shape)
        
        return X_
    
    def transform(self, X):

        col_name = X.columns[0]
        X = X[col_name].fillna('').astype(str)
        

        if self.config['cache_dir'] is not None:
            full_hash = get_textarr_hash(X)
            fname = os.path.join(self.config['cache_dir'], col_name + full_hash + '.pkl')
            if os.path.exists(fname):
                print('Load saved tokenization for', col_name) 
                X = joblib.load(fname)
            else:
                print('Tokenization..')
                X = self.tokenizer.tokenize_array(X, n_jobs = self.n_jobs) 
                joblib.dump(X, fname)
        else:
            print('Cache dir is empty', self.config['cache_dir'], )
            X = self.tokenizer.tokenize_array(X, n_jobs = self.n_jobs)                    

        print('TRANSFORM Transforming')
        X_ = self.transformer.transform(X)    
        print(X_.shape)
        
        return X_

