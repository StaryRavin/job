import pandas as pd
from pandas import Series, DataFrame

import numpy as np
from numpy import random
random.seed(999)

import gc
import sys
import os


import datetime
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.utils import murmurhash3_32
from sklearn.linear_model import SGDClassifier, SGDRegressor
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.model_selection import StratifiedKFold, KFold, cross_val_predict

from copy import deepcopy

from itertools import combinations


holi_dir= os.path.dirname(__file__) 
holi = pd.DatetimeIndex(pd.read_csv(holi_dir + r'/holidays.csv')['datetime_0'])


# date tools
class TimeToCat(TransformerMixin, BaseEstimator):
    
    def __init__(self, basic_time = '1970-01-01', basic_interval = 'D', dtype = np.float32, hour_bin = 1, month_bin = 1, day_bin = 1):
        super().__init__()
        self.basic_time = '1970-01-01'
        self.basic_interval = basic_interval
        self.dtype = np.float32
        self.hour_bin = hour_bin
        self.month_bin = month_bin
        self.day_bin = day_bin
        
        
    def fit(self, X, y = None):
             
        return self
    
    def transform(self, X, y = None):
        
        res = DataFrame(index = X.index)
        
        for i in X.columns:
            dcol = X[i] #.astype(np.datetime64)
            seconds = dcol.dtype == np.dtype('datetime64[ns]')
            dcol = pd.DatetimeIndex(dcol)
            if seconds:
                res[i + '_hour'] = (dcol.hour.values // self.hour_bin).astype(self.dtype)
            res[i + '_month'] = (dcol.month.values // self.month_bin).astype(self.dtype)
            res[i + '_day'] = (dcol.day.values // self.day_bin).astype(self.dtype)
            res[i + '_weekday'] = dcol.weekday.values.astype(self.dtype)
            #res[i + '_year'] = dcol.year.values.astype(self.dtype)

            res[i + '_wd'] = dcol.map(lambda x: x in holi).values.astype(self.dtype)    
            
        self.feature_names = list(res.columns)
        return res
    
    def get_feature_names(self):
        
        return self.feature_names
    
    
class TimeToNum(TransformerMixin, BaseEstimator):
    
    def __init__(self, basic_time = '1970-01-01', basic_interval = 'D', dtype = np.float32):
        super().__init__()
        self.basic_time = '1970-01-01'
        self.basic_interval = basic_interval
        self.dtype = np.float32
        
        
    def fit(self, X, y = None):
        
        
        return self
    
    def transform(self, X, y = None):
        
        res = DataFrame(index = X.index)
        
        for i in X.columns:
            res[i] = ((X[i] # .astype(np.datetime64) 
                       - np.datetime64(self.basic_time)) / np.timedelta64(1, \
                                                               self.basic_interval)).astype(self.dtype)
            
        self.feature_names = list(res.columns)
        return res
    
    def get_feature_names(self):
        
        return self.feature_names



class DateDiff(BaseEstimator, TransformerMixin):
    
    def __init__(self, dtype = np.float32):
        self.dtype = dtype
        
    def fit(self, X, y = None):
        
        cols_list = list(X.columns)
        self.interactions = list(combinations(cols_list, 2))
        self.feature_names = ['ddiff_' + '_'.join(x)  for x in self.interactions]
        # print(self.interactions, self.feature_names)
        return self
        
    def get_feature_names(self):
        return self.feature_names
    
    def transform(self, X):
        
        res = DataFrame(index = X.index)
        for n, (i, j) in zip(self.feature_names, self.interactions):
            res[n] = ((X[i] # .astype(np.datetime64) 
                        - X[j] #.astype(np.datetime64)
                      ) / np.timedelta64(1, 'D')).values.astype(self.dtype)
        # print(res.dtypes, res.columns)
        return res #.astype(self.dtype)






