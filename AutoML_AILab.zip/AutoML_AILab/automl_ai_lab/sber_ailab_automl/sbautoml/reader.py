import numpy as np
from numpy import random
from numpy.linalg import norm
from pandas import Series, DataFrame

random.seed(999)

import gc
import sys
sys.path.append('..')

import lightgbm as lgb
from copy import deepcopy

from .dataset import AutoMLDataset
from .pipelines.make_pipeline import make_pipeline_basic, make_pipeline_middle, make_pipeline_reg
from .transformers.nlp_wrapper.text_tokenizer import Tokenizer

from sklearn.model_selection import train_test_split, KFold, StratifiedKFold
from sklearn.metrics import mean_squared_error, roc_auc_score
from sklearn import metrics

import xgboost as xgb

import psutil

from ..lib.util import timeit, log, GroupKFoldSeed, feval_deco_common, StratifiedGroupKFold

import gensim
from .transformers.nlp_wrapper.nlp_wrappers import model_path as mystem_path
import shap

def convert_feat_name(x, config):
    return config['fileb'].inv_names[x.split('__')[1]]


def calculate_metric_score(y_true, y_pred, config):
    if config["metric"][0] is None:
        if config["mode"] == 'regression':
            return np.sqrt(mean_squared_error(y_true, y_pred))
        else:
            return roc_auc_score(y_true, y_pred)
    elif isinstance(config["metric"][0], str):
        return getattr(metrics, config["metric"][0])(y_true, y_pred)
    else:
        return config["metric"][0](y_true, y_pred)

# def get_fi_old(model, pipe, X_test = None, config = None):
#     explainer = shap.TreeExplainer(model)
#     if X_test.shape[0] < 25000:
#         shap_v = explainer.shap_values(X_test)[1]
#     else:
#         shap_v = explainer.shap_values(X_test[np.random.choice(X_test.shape[0], 25000, replace = False), :])[1]
        
#     imp = DataFrame({'feat': pipe.get_feature_names(), 'imp': np.abs(shap_v).mean(axis = 0), 'idx': list(range(X_test.shape[1]))})
    
#     imp.sort_values('imp', ascending=False, inplace = True)

#     print('=' * 50)
#     for x, y in zip(imp.feat, imp.imp):
#         print(convert_feat_name(x, config), round(y, 9))
#     print('=' * 50)

#     return imp


def get_fi(model, pipe, X_test, Y_test, config):
    fnames = pipe.get_feature_names()
    imp_arr = []
    full_score = calculate_metric_score(Y_test, model.predict(X_test), config)
    for i in range(X_test.shape[1]):
        hold = X_test[:, i].copy()
        random.shuffle(X_test[:, i])
        res_diff = full_score - calculate_metric_score(Y_test, model.predict(X_test), config)
        imp_arr.append([fnames[i], res_diff, i])
        X_test[:, i] = hold
        if i % 10 == 0:
            print('{}/{} feats done'.format(i + 1, X_test.shape[1]))
            
    imp = DataFrame(imp_arr, columns = ['feat', 'imp', 'idx'])
    
    imp.sort_values('imp', ascending=(not config["metric"][1]), inplace = True)

    print('=' * 50)
    for x, y in zip(imp.feat, imp.imp):
        print(convert_feat_name(x, config), round(y, 9))
    print('=' * 50)

    return imp


cl_params = {
    'task': 'train',
    'boosting_type': 'gbdt',
    'objective': 'binary',
    'metric': 'auc',
    "learning_rate": 0.05,
    "num_leaves": 128,
    "feature_fraction": 0.70,
    "bagging_fraction": 0.70,
    'bagging_freq': 1,
    "max_depth": -1,
    "verbosity": -1,
    "reg_alpha": 1,
    "reg_lambda": 0.0,
    "min_split_gain": 0.0,
    "min_child_weight": 0,
    'zero_as_missing': False,
    'num_threads': 4,
    'max_bin': 255,
    'min_data_in_bin': 3
}

reg_params = {
    'task': 'train',
    'boosting_type': 'gbdt',
    'objective': 'regression',
    'metric': 'rmse',
    "learning_rate": 0.05,
    "num_leaves": 32,
    "feature_fraction": 0.9,
    "bagging_fraction": 0.9,
    'bagging_freq': 1,
    "max_depth": -1,
    "verbosity": -1,
    "reg_alpha": 1,
    "reg_lambda": 0,
    "min_split_gain": 0.0,
    "min_child_weight": 0,
    'zero_as_missing': False,
    'num_threads': 4,
    'max_bin': 255,
    'min_data_in_bin': 3
}


def get_feats_from_pipelines(*pipes):
    
    feats = []
    
    for pipe in pipes:
        for trnf in pipe.named_steps['features'].transformer_list:
            trnf = trnf[1]
            for sel in trnf.named_steps:
                feats += trnf.named_steps[sel].keys
                break
    feats = sorted(list(set(feats)))
    return feats


def get_simple_df(dataset, MEMORY_LIMIT, random_state = 42, copy_times = None):
    
    random.seed(random_state)
    memory_usage = dataset.check_memory()

    # check max_avail_subset
    if memory_usage > MEMORY_LIMIT:
        max_avail_subset = (MEMORY_LIMIT / memory_usage)

        # for reg take subset   
        if dataset.task == 'r':
            rate_drop = 1 - max_avail_subset
            index = np.sort(random.choice(np.arange(dataset.rows), int(dataset.rows * rate_drop), replace = False))
            
        # for classif we take balanced subsample
        else:
            print("We are sampling the data to fit the memory")
            min_cl = int(dataset.target.mean() < 0.5)
            min_cl_sample = (dataset.target == min_cl).mean()
            min_cl_rate = min(1, max_avail_subset / 2 / min_cl_sample)
            max_avail_big = max_avail_subset - min_cl_sample * min_cl_rate
            max_cl_rate = max_avail_big / (1 - min_cl_sample) 
            skip = []
            if min_cl_rate < 1:
                sl = dataset.target == min_cl
                skip_min = np.arange(dataset.target.shape[0])[sl]
                skip_min = random.choice(skip_min, int(sl.sum() * (1 - min_cl_rate)), replace = False, )
                skip.append(skip_min)
            if max_cl_rate < 1:
                sl = dataset.target != min_cl
                skip_max = np.arange(dataset.target.shape[0])[sl]
                skip_max = random.choice(skip_max, int(sl.sum() * (1 - max_cl_rate)), replace = False, )
                skip.append(skip_max)
            index = np.sort(np.concatenate(skip))
        memleft = psutil.virtual_memory().available / 1024 ** 3
        df = dataset.get_df(skiprows = index)
    else:
        memleft = psutil.virtual_memory().available / 1024 ** 3
        df = dataset.get_df()
    gc.collect()
    memnew = psutil.virtual_memory().available / 1024 ** 3
    df_size = memleft - memnew

    print('DF size = {0}'.format(df_size), 'Mem left = {}'.format(memnew))
    if copy_times is not None:
        
        if df_size > 0.05 and (memnew / df_size ) < copy_times:
            rate = memnew / df_size 
            print(memnew / df_size )
            sl = random.choice([1, 0], df.shape[0],  p = [rate / copy_times, 1 - rate / copy_times]).astype(np.bool)
            print('Subsample', rate / copy_times)
            df = df[sl]
            return df, sl
        else:
            sl = np.ones(df.shape[0], dtype = np.int32).astype(np.bool)
            return df, sl
    else:
        return df


def get_initial_params(dataset, VCPU_LIMIT):
    
    if dataset.rows <= 20000:
        init_lr = 0.02
        ntrees = 5000
        es = 200

    elif dataset.rows <= 100000:
        init_lr = 0.05
        ntrees = 1200
        es = 200
    elif dataset.rows <= 300000:
        init_lr = 0.05
        ntrees = 2000
        es = 100
    else:
        init_lr = 0.05
        ntrees = 2000
        es = 100
    #####################
    # manual tune params
    params = deepcopy(reg_params) if dataset.task == 'r' else deepcopy(cl_params)
    
    if dataset.rows > 300000:
        params['num_leaves'] = 128 if dataset.task == 'r' else 244
    elif dataset.rows > 100000:
        params['num_leaves'] = 64 if dataset.task == 'r' else 128
    elif dataset.rows > 50000:
        params['num_leaves'] = 32 if dataset.task == 'r' else 64  
        # params['reg_alpha'] = 1 if dataset.task == 'r' else 0.5 
    elif dataset.rows > 20000:
        params['num_leaves'] = 32 if dataset.task == 'r' else 32
        params['reg_alpha'] = 0.5 if dataset.task == 'r' else 0.0
    elif dataset.rows > 10000:
        params['num_leaves'] = 32 if dataset.task == 'r' else 64
        params['reg_alpha'] = 0.5 if dataset.task == 'r' else 0.2
    elif dataset.rows > 5000:
        params['num_leaves'] = 24 if dataset.task == 'r' else 32
        params['reg_alpha'] = 0.5 if dataset.task == 'r' else 0.5
    else:
        params['num_leaves'] = 16 if dataset.task == 'r' else 16
        params['reg_alpha'] = 1 if dataset.task == 'r' else 1
        
    train_params = deepcopy(params)
    train_params['learning_rate'] = init_lr
    train_params['num_threads'] = VCPU_LIMIT
    
    return train_params, ntrees, es


class EarlySaver:

    def __init__(self, maximize_score):
        self.state = {}
        self.maximize_score = maximize_score

    def first_run(self, env):
        """internal function"""
        bst = env.model

        if len(env.evaluation_result_list) == 0:
            raise ValueError('For early stopping you need at least one set in evals.')

        self.state['best_iteration'] = 0
        if self.maximize_score:
            self.state['best_score'] = float('-inf')
        else:
            self.state['best_score'] = float('inf')

        if bst is not None:
            if bst.attr('best_score') is not None:
                self.state['best_score'] = float(bst.attr('best_score'))
                self.state['best_iteration'] = int(bst.attr('best_iteration'))
                self.state['best_msg'] = bst.attr('best_msg')
            else:
                bst.set_attr(best_iteration=str(self.state['best_iteration']))
                bst.set_attr(best_score=str(self.state['best_score']))
        else:
            assert env.cvfolds is not None

    def __call__(self, env):

        score = env.evaluation_result_list[-1][1]
        if len(self.state) == 0:
            self.first_run(env)

        best_score = self.state['best_score']
        if (self.maximize_score and score > best_score) or \
                (not self.maximize_score and score < best_score):

            self.state['best_score'] = score
            # print(maximize_score, score)
            self.state['best_iteration'] = env.iteration
            self.booster = deepcopy(env.model)

            if env.model is not None:
                env.model.set_attr(best_score=str(self.state['best_score']),
                                   best_iteration=str(self.state['best_iteration']), )
        return None


def get_initial_xgb(dataset, VCPU_LIMIT):
    
    xgb_params = {
 
        'booster'         : 'gblinear',
        'nthread'         : 4,
        'subsample'       : 0.99,
        'colsample_bytree': 0.99,
        'reg_alpha'       : 0.000,
        'reg_lambda'      : 0,
        'seed'            : 42,

    }

    xgb_params = deepcopy(xgb_params)
    xgb_params['objective'] = 'reg:squarederror' if dataset.task == 'r' else 'binary:logistic'
    xgb_params['eta'] = 0.1
    xgb_params['eta_decay'] = 1 if dataset.task == 'r' else 0.95
    
    xgb_params['eval_metric'] = 'rmse' if dataset.task == 'r' else 'auc'
    xgb_es = 20
    xgb_iter = 600
    
    xgb_params['nthread'] = VCPU_LIMIT

    return xgb_params, xgb_iter, xgb_es


def train_embedding(texts, dataset, text_n_jobs = 1, embeddings_path = None):
    
    roles = dataset.roles
    text_cols = roles['txt']
    
    if len(text_cols) == 0:
        return None
    
    text_arr = list(texts[text_cols[0]])
    for t in text_cols[1:]:
        text_arr.extend(texts[t])
    
    tokenizer = Tokenizer(mystem_path,  postags=False, use_stemmer=False)
    X = tokenizer.tokenize_array(text_arr, n_jobs = text_n_jobs)

    if embeddings_path is not None:
        embedding_model = gensim.models.FastText.load(embeddings_path)
    else:
        embedding_model = gensim.models.FastText(size = 100, min_count = 5, sg = 1)
        embedding_model.build_vocab(X)
        embedding_model.train(X, total_examples = len(X), epochs = 3)
    
    return embedding_model
    

def train_linear(dataset, fs, MEMORY_LIMIT, VCPU_LIMIT, emb, use_ids = False, config = None):
    df, sl = get_simple_df(dataset, MEMORY_LIMIT, copy_times = 10, )
    sf = list(map(lambda x: x.split('__')[1], fs))
    df = df[sf + ['target'] + (['group'] if 'group' in df.columns else []) + (['weight'] if 'weight' in df.columns else [])]
    
    gc.collect()
    ########## make pipeline
    Y = df['target'].values 
    group = df['group'].values if 'group' in df.columns else None
    weight = df['weight'].values if 'weight' in df.columns else None
    pipe = make_pipeline_reg(dataset, fs, use = True, use_ids = use_ids, text_n_jobs = VCPU_LIMIT, embedding = emb, config = config)
    ###################
    # check memory
    # succes = np.ones_like(Y)
    memleft = psutil.virtual_memory().available / 1024 ** 3
    print('Memory left', memleft)
    ##################
    X = pipe.fit_transform(df, Y) 
    print(X.dtype)
    
    print_feats_used = [config['fileb'].inv_names[x] for x in get_feats_from_pipelines(pipe)]
    print('IN XGB MODELS WE USE THIS FEATS = {}'.format(print_feats_used))
    config.write_to_logfile('IN XGB MODELS WE USE THIS FEATS = {}'.format(print_feats_used))
    print('NUM_FEATS_USED = {}'.format(len(print_feats_used)))
    config.write_to_logfile('NUM_FEATS_USED = {}'.format(len(print_feats_used)))
    
    memleft = psutil.virtual_memory().available / 1024 ** 3
    print('Memory left', memleft)
    del df
    gc.collect()
    #######################

    if group is not None:
        sgr = Series(group)
        assert sgr.isnull().any() == False, 'Group contains NaN'
        if config["mode"] == 'regression':
            folds = GroupKFoldSeed(n_splits=min(config['KFolds'], sgr.nunique()),
                                random_state=config['cv_random_state']).split(group.values, group.values, group.values)
        else:
            stratified_group_k_fold = StratifiedGroupKFold()
            folds = stratified_group_k_fold(group, Y, group, k=min(config['KFolds'], sgr.nunique()), seed = config['cv_random_state'])
    else:
        if dataset.task == 'c':
            folds = StratifiedKFold(config['KFolds'], shuffle = True, random_state = config['cv_random_state']).split(Y, Y)
        else:
            folds = KFold(config['KFolds'], shuffle = True, random_state = config['cv_random_state']).split(Y, Y)
    print('WE ARE USING CV_RANDOM_STATE = {}'.format(config['cv_random_state']))
    config.write_to_logfile('WE ARE USING CV_RANDOM_STATE = {}'.format(config['cv_random_state']))
    
    models = []
    xgb_params, xgb_iter, xgb_es = get_initial_xgb(dataset, VCPU_LIMIT)
    print('XGB MODELS PARAMS = {}, MAX_NUM_TREES = {}, EARLY_STOPPING_ROUNDS = {}'.format(xgb_params, xgb_iter, xgb_es))
    config.write_to_logfile('XGB MODELS PARAMS = {}, MAX_NUM_TREES = {}, EARLY_STOPPING_ROUNDS = {}'.format(xgb_params, xgb_iter, xgb_es))
    
    oof_pred = np.zeros_like(Y, dtype=np.float32)
    oof_pred1 = np.zeros_like(Y, dtype=np.float32)
    ######################
    
    for n, (f0, f1) in enumerate(folds):
        log("Fold {} ".format(n) + '=' * 90)
        X_tr = xgb.DMatrix(X[f0], label=Y[f0], weight = None if weight is None else weight[f0])
        X_val = xgb.DMatrix(X[f1], label=Y[f1], # weight = None if weight is None else weight[f1] 
)

        maximize = config["metric"][1]    # False if xgb_params['objective'] == 'reg:squarederror' else True
        saver = EarlySaver(maximize) ######################################################################################## TODO !!!!!

        if config["metric"][0] is None:
            feval_func = None
        elif isinstance(config["metric"][0], str):
            feval_func = feval_deco_common("xgb")(getattr(metrics, config["metric"][0]))
        else:
            feval_func = feval_deco_common("xgb")(config["metric"][0])

        model = xgb.train(xgb_params, X_tr, num_boost_round=xgb_iter, evals=[(X_val, 'valid')],
                          feval=feval_func,
                          maximize=maximize,
                          early_stopping_rounds=xgb_es,
                          verbose_eval=10, callbacks=[saver],)

        if group is not None:
            print('Intersection', len(set(group[f0]).intersection(set(group[f1]))))
        else:
            print('No groups')
        model = saver.booster

        models.append(model)
        oof_pred[f1] = model.predict(X_val)

        if config["metric"][0] is None:
            if dataset.task == 'r':
                print("FOLD = {}, XGB_RMSE_SCORE = {}".format(n, np.sqrt(mean_squared_error(Y[f1], oof_pred[f1]))))
                config.write_to_logfile("FOLD = {}, XGB_RMSE_SCORE = {}".format(n, np.sqrt(mean_squared_error(Y[f1], oof_pred[f1]))))
            else:
                print("FOLD = {}, XGB_AUC_SCORE = {}".format(n, roc_auc_score(Y[f1], oof_pred[f1])))
                config.write_to_logfile("FOLD = {}, XGB_AUC_SCORE = {}".format(n, roc_auc_score(Y[f1], oof_pred[f1])))

        elif isinstance(config["metric"][0], str):
            print("FOLD = {}, XGB_{} = {}".format(n, config["metric"][0],
                                                  getattr(metrics, config["metric"][0])(Y[f1], oof_pred[f1])))
            config.write_to_logfile("FOLD = {}, XGB_{} = {}".format(n, config["metric"][0],
                                    getattr(metrics, config["metric"][0])(Y[f1], oof_pred[f1])))
        else:
            print("FOLD = {}, XGB_{} = {}".format(n, config["metric"][0].__name__,
                                                  config["metric"][0](Y[f1], oof_pred[f1])))
            config.write_to_logfile("FOLD = {}, XGB_{} = {}".format(n, config["metric"][0].__name__,
                                                                    config["metric"][0](Y[f1], oof_pred[f1])))

        del X_tr, X_val
        gc.collect()

    return pipe, models, oof_pred, sl# , emb


####################################################################################################################
def create_chunks_from_list(lst, n):
    chunks = []
    for i in range(0, len(lst), n):
        chunks.append(lst[i:i + n])
    return chunks

@timeit
def get_train_df_w_reg(fb, TASK, MEMORY_LIMIT, VCPU_LIMIT, use_ids = False, encoding = 'utf-8', separator = ',', decimal = '.', featureRoles={}, config = None):
    
    dataset = AutoMLDataset(fb, task = TASK)
    #####################

    #####################
    df = get_simple_df(dataset, MEMORY_LIMIT)
    config.write_to_logfile('Получение рабочего датасета')
    
    emb = train_embedding(df, dataset, text_n_jobs = VCPU_LIMIT, embeddings_path = config['embeddings_path'])

    print(emb)
    
    # print(df.dtypes)
    ########## make pipeline
    Y = df['target'].values 
    group = df['group'].values if 'group' in df.columns else None
    pipe = make_pipeline_basic(dataset, n_jobs = 1, task = dataset.task, text_n_jobs = VCPU_LIMIT)
    X = pipe.fit_transform(df, Y)
    feats = pipe.get_feature_names()
    
    print_feats_used = [config['fileb'].inv_names[x] for x in get_feats_from_pipelines(pipe)]
    print('IN FEATURE SELECTION LIGHTGBM WE USE THIS FEATS = {}'.format(print_feats_used))
    config.write_to_logfile('IN FEATURE SELECTION LIGHTGBM WE USE THIS FEATS = {}'.format(print_feats_used))
    print('NUM_FEATS_USED = {}'.format(len(print_feats_used)))
    config.write_to_logfile('NUM_FEATS_USED = {}'.format(len(print_feats_used)))

    cats = [x for x in feats if x[:4] == 'cat_']
    #print(X.dtype)
    config.write_to_logfile('Генерация новых признаков для линейной модели')
    #######################
    del df 
    gc.collect()  
    #######################
    train_params, ntrees, es = get_initial_params(dataset, VCPU_LIMIT)

    if config["metric"][0] is None:
        feval_func = None
    else:
        maximize = config["metric"][1]  # False if config["mode"] == 'regression' else True
        train_params["metric"] = "None"
        if isinstance(config["metric"][0], str):
            feval_func = feval_deco_common("lgb", maximize)(getattr(metrics, config["metric"][0]))
        else:
            feval_func = feval_deco_common("lgb", maximize)(config["metric"][0])

    print('FEATURE SELECTION LGBM PARAMS = {}, MAX_NUM_TREES = {}, EARLY_STOPPING_ROUNDS = {}'.format(train_params, ntrees, es))
    config.write_to_logfile('FEATURE SELECTION LGBM PARAMS = {}, MAX_NUM_TREES = {}, EARLY_STOPPING_ROUNDS = {}'.format(train_params, ntrees, es))
    
    N_FEAT_SEL_FOLDS = 5
    if group is not None:
        sgr = Series(group)
        assert sgr.isnull().any() == False, 'Group contains NaN'
        if config["mode"] == 'regression':
            folds = GroupKFoldSeed(n_splits=min(N_FEAT_SEL_FOLDS, sgr.nunique()),
                                random_state=config['cv_random_state'] + 1).split(group, group, group)
        else:
            stratified_group_k_fold = StratifiedGroupKFold()
            folds = stratified_group_k_fold(group, Y, group, k=min(N_FEAT_SEL_FOLDS, sgr.nunique()), seed = config['cv_random_state'] + 1)
    else:
        if dataset.task == 'c':
            folds = StratifiedKFold(N_FEAT_SEL_FOLDS, shuffle = True, random_state = config['cv_random_state'] + 1).split(Y, Y)
        else:
            folds = KFold(N_FEAT_SEL_FOLDS, shuffle = True, random_state = config['cv_random_state'] + 1).split(Y, Y)
    
    for f0, f1 in folds:
        break
        
    X, X_ref, Y, Y_ref = X[f0], X[f1], Y[f0], Y[f1]
    

    X_train = lgb.Dataset(X, label=Y, feature_name=feats, categorical_feature=cats )
    
    X_validation = lgb.Dataset(X_ref, label=Y_ref, feature_name=feats, categorical_feature=cats,
                               free_raw_data=False)

    ######################
    model = lgb.train(train_params, X_train, num_boost_round = ntrees, feature_name = feats,
                      categorical_feature = cats, valid_sets = [X_validation], early_stopping_rounds = es,
                      verbose_eval = 100, keep_training_booster=False, feval=feval_func)

    #####################
    del X_train, X_validation
    gc.collect()
    #####################

    #####################
    # select feats
    
    imp = get_fi(model, pipe, X_ref, Y_ref, config)

    if config['featureSelParams'][2]:
        if config["metric"][1]:
            feat_order = imp[imp.imp > 0]
        else:
            feat_order = imp[imp.imp < 0]
    else:
        feat_order = imp.copy()
        
    if config['featureSelParams'][0] is not None:
        FEAT_SEL_BOUND = int(config['featureSelParams'][0])
        N_GR_FEATS = int(config['featureSelParams'][1])
        sel_feats = []
        test_preds = np.array([0.0] * X_ref.shape[0])
        best_score = 0
        
        feat_idx = feat_order.idx.values
        feat_names = feat_order.feat.values
        
        fn = []

        cnt_without_change = 0
        fl_rewrite = False
        
        zipped_feats = list(zip(feat_names, feat_idx))
        chunks = create_chunks_from_list(zipped_feats, N_GR_FEATS)
        for it, chunk in enumerate(chunks):
            _fnames = [f[0] for f in chunk]
            _fids = [f[1] for f in chunk]
            
            print('**** ITER = {}/{}, FEATS = {} *****'.format(it + 1, len(chunks), [convert_feat_name(feat, config) for feat in _fnames]))
            
            if it == 0:
                temp_X_train = X[:, _fids]
                temp_X_test = X_ref[:, _fids]
                fn = _fnames[:]
            else:   
                if fl_rewrite:
                    if it != len(chunks) - 1:
                        temp_X_train[:, -N_GR_FEATS:] = X[:, _fids]
                        temp_X_test[:, -N_GR_FEATS:] = X_ref[:, _fids]
                        fn[-N_GR_FEATS:] = _fnames[:]
                    else:
                        # delete bigger part
                        temp_X_train = temp_X_train[:, :-N_GR_FEATS]
                        temp_X_test = temp_X_test[:, :-N_GR_FEATS]
                        fn = fn[:-N_GR_FEATS]
                        # append last part
                        temp_X_train = np.hstack((temp_X_train, X[:, _fids]))
                        temp_X_test = np.hstack((temp_X_test, X_ref[:, _fids]))
                        fn += _fnames[:]
                else:
                    temp_X_train = np.hstack((temp_X_train, X[:, _fids]))
                    temp_X_test = np.hstack((temp_X_test, X_ref[:, _fids]))
                    fn += _fnames[:]

            cn = [x for x in fn if x in cats]

            F_X_train = lgb.Dataset(temp_X_train, label=Y, feature_name=fn, categorical_feature=cn)
            F_X_validation = lgb.Dataset(temp_X_test, label=Y_ref, feature_name=fn, categorical_feature=cn, free_raw_data=False)

            model = lgb.train(train_params, F_X_train, num_boost_round = ntrees, feature_name = fn,
                          categorical_feature = cn, valid_sets = [F_X_validation], early_stopping_rounds = 50,
                          verbose_eval = 100, keep_training_booster=False, feval=feval_func)

            del F_X_train, F_X_validation
            gc.collect()

            F_test_preds = model.predict(temp_X_test)
            sc = calculate_metric_score(Y_ref, F_test_preds, config)

            print('**** SCORE = {} *****'.format(sc))
            if (it == 0) or (config["metric"][1] and sc > best_score) or (not config["metric"][1] and sc < best_score):
                best_score = sc
                print('**** BEST SCORE UPD = {}, NEW_SEL_FEATS = {}, SEL_FEATS_CNT = {} *****'.format(sc, [convert_feat_name(x, config) for x in fn], len(fn)))
                cnt_without_change = 0
                fl_rewrite = False
                if FEAT_SEL_BOUND > 0 and len(fn) >= FEAT_SEL_BOUND:
                    print('**** REACHED FEATURE_SEL_BOUND - EXIT FROM FEATURE SELECTION ALGORITHM*****')
                    break
            else:
                fl_rewrite = True
                cnt_without_change += 1
                print('**** WITHOUT_UPDATE = {} *****'.format(cnt_without_change))

        if fl_rewrite:
            fn = fn[:-len(_fids)]
            
        del X, Y, X_ref, Y_ref, temp_X_train, temp_X_test
        gc.collect()
    else:
        fn = list(feat_order['feat'].values)
    
    selected = list(map(lambda x: x.split('__')[1], fn))
    print('Dropped', len(imp) - len(selected), 'feats')  
    imp = imp[imp['feat'].isin(fn)]
    config['feat_imp'] = Series(index = imp['feat'].values, data = imp['imp'].values)
    dataset.select_feats(selected)
    
    config.write_to_logfile('Отбор признаков')
    #####################
    # train reg
    reg_pipe, reg_models, reg_oof_pred, reg_sl = train_linear(dataset, fn, MEMORY_LIMIT, VCPU_LIMIT, emb, use_ids = use_ids, config = config)
    reg_dataset = deepcopy(dataset)    
    config.write_to_logfile('Тренировка линейной модели')
    
    #####################
    # final df
    df = get_simple_df(dataset, MEMORY_LIMIT)
    print(df.columns)
    df = df[list(selected) + ['target'] + (['group'] if 'group' in df.columns else [])
           ]
    #print(df.columns)
    
    
    gc.collect()
    if dataset.task == 'r':
        co = 10
    else:
        co = 3
    #print(df.columns)
    
    group = None if not 'group' in df.columns else df['group']
    weight = None if not 'weight' in df.columns else df['weight']
    Y = df['target'].values 
    pipe = make_pipeline_middle(dataset, fn, cat_co = co, n_jobs = 1, use_ids = use_ids, text_n_jobs = VCPU_LIMIT, embedding = emb, config = config)
    
    X = pipe.fit_transform(df, Y)
    feats = pipe.get_feature_names()
    
    print_feats_used = [config['fileb'].inv_names[x] for x in get_feats_from_pipelines(pipe)]
    print('IN LGBM MODELS WE USE THIS FEATS = {}'.format(print_feats_used))
    config.write_to_logfile('IN LGBM MODELS WE USE THIS FEATS = {}'.format(print_feats_used))
    print('NUM_FEATS_USED = {}'.format(len(print_feats_used)))
    config.write_to_logfile('NUM_FEATS_USED = {}'.format(len(print_feats_used)))
    
    if TASK == 'r':
        cats = [x for x in feats if x[:4] == 'cat_' or x[:4] == 'dt__']
    else:
        cats = None

    index = df.index.values
    del df
    gc.collect()
    #print(X.dtype)
    config.write_to_logfile('Генерация новых признаков для LGBM')
    #####################
    print(X.shape, len(feats))
    df = DataFrame(X, columns = feats)
    df['target'] = Y
    df['line_id'] = index
    del X
    gc.collect()
    return df, group, weight, dataset, pipe, cats, reg_pipe, reg_models, reg_oof_pred, reg_dataset, reg_sl


def get_pred_iterator_reg(dataset, fb, pipe, batch_size = 10000):
    df_iter = dataset.get_df(fb = fb, chunksize = batch_size, test = True)
    for df in df_iter:
        yield xgb.DMatrix(pipe.transform(df)), df.index.values


def get_pred_iterator(dataset, fb, pipe, batch_size = 10000):
    df_iter = dataset.get_df(fb = fb, chunksize = batch_size, test = True)
    for df in df_iter:
        fl = False
        if 'target' in df.columns:
            tar = df['target'].values
            fl = True
        X = pipe.transform(df)
        index = df.index.values
        df = DataFrame(X, columns = pipe.get_feature_names())
        df['line_id'] = index
        if fl:
            df['target'] = tar
        yield df


