import pandas as pd
from pandas import Series, DataFrame

import re
import datetime as dt

from collections import defaultdict, Counter
import shutil

import os
import numpy as np

# alias
roles_types_map = {

    'number': ('number', np.float32),
    'num': ('number', np.float32),
    'numeric': ('number', np.float32),
    'interval': ('number', np.float32),


    'target': ('target', np.float32),


    'dt': ('datetime', np.str),
    'datetime': ('datetime', np.str),
    'date': ('datetime', np.str),
    'time': ('datetime', np.str),

    'category': ('string', np.str),
    'categorical': ('string', np.str),
    'cat': ('string', np.str),
    'str': ('string', np.str),
    'string': ('string', np.str),

    'id': ('id', np.str),

    'drop': ('drop', None),
    'reject': ('drop', None),
    'rejected': ('drop', None),
    
    'line_id': ('line_id', np.int64),
    
    'group': ('group', np.str),
    
    'text': ('text', str),
    
    'weight': ('weight', np.float32)

}



def get_dtype(df, col, dateformat = None):

    vals = df[col].fillna(df[col].dropna().values[0]).values
    
    if vals.dtype != np.dtype('O'):
        return 'number', np.float32
    else:
        try:
            pd.to_datetime(vals, format = dateformat).values + np.timedelta64(1)
        except Exception:
            return 'string', np.str
        else:
            return 'datetime', np.str
    
    
def temp_func():
    return [None, None]

    
def safe_replace(order, row, mapping):
    
    str1 = ''
    str2 = row
    
    for col in order:
        l = str2.split(col)
        if col in mapping:
            str1 += l[0] + str(mapping[col])
        else:
            str1 += l[0] + str(col)
        str2 = col.join(l[1:])
    
    return str1 + str2
    

    
class FileBuilder():
    
    def __init__(self, data_roles, analyze_rows = 100, sep = ',', encoding = 'utf-8', na_values = None, 
                 decimal = b'.', datetime_format = None):
        
        self.sep = sep
        self.analyze_rows = analyze_rows
        
        assert 'target' in data_roles, 'Target must be defined'
              
        self.fixed_types = defaultdict(temp_func)
        
        self.index_col =  'line_id' if 'line_id' in data_roles else None
        self.initial_line_id = data_roles['line_id'] if 'line_id' in data_roles else None

        self.datetime_format = datetime_format
        
        self.target_name = data_roles['target']
        self.group_name  = data_roles['group'] if 'group' in data_roles else None
        
        
        for k in data_roles:
            
            if k in ['target', 'line', 'line_id', 'group', 'weight']:
                print(k, data_roles[k], )
                self.fixed_types[data_roles[k]] = roles_types_map[k]
            else:
                
                for v in data_roles[k]:
                    try:
                        self.fixed_types[v] = roles_types_map[k]
                    except KeyError:
                        print('Unknown role {0}'.format(k))
                        
        
        self.params = {
            
            'encoding': encoding,
            'na_values': na_values, 
            'decimal': decimal,
            'sep': sep
            
        }
        
        self.last_fname = None
        
    
    def _create(self, fname):
    
        self.last_fname = fname
    
        subs = pd.read_csv(fname, nrows = 2, **self.params)
        cols = list(subs.columns)

        assert self.initial_line_id in cols or self.initial_line_id is None, 'Missing line_id column'
        
        self.last_cols = cols
        self.last_target = self.target_name in cols
        
        with open(fname, 'r', encoding = self.params['encoding']) as f1:

            header = f1.readline()
            self.last_offset = len(bytes(header, encoding = self.params['encoding']))
            self.last_header = [self.names[x] if x in self.names else x for x in cols]
            self.rows_limit = None
            
        return None
    
    def _create_mem(self, fname):
    
        self.last_fname = fname

        cols = list(fname.columns)

        assert self.initial_line_id in cols or self.initial_line_id is None, 'Missing line_id column'
        self.last_cols = cols
        self.last_target = self.target_name in cols
        self.last_offset = None
        self.rows_limit = None
        self.last_header = [self.names[x] if x in self.names else x for x in cols]
            
        return None
    
    def create(self, fname):
        
        if type(fname) is str:
            return self._create(fname)
        else:
            return self._create_mem(fname)
    
    
    def drop_last(self, ):
        del self.last_fname


    def set_rows_limit(self, limit = None, offset = None):

        if limit is not None:
            self.rows_limit = limit
        if offset is not None:
            self.last_offset = offset
    
    def _get_subset(self, fname, ):
        
        subs = pd.read_csv(fname, nrows = self.analyze_rows, **self.params)
        return subs
    
    def _get_subset_mem(self, fname, ):
        
        subs = fname.sample(self.analyze_rows, axis = 0) if self.analyze_rows < fname.shape[0] else fname
        return subs
    
    
    def get_subset(self, fname, ):
        
        if type(fname) is str:
            return self._get_subset(fname)
        else:
            return self._get_subset_mem(fname)
        
        
    def create_mapping(self, fname):
        
        subs = self.get_subset(fname, )
        self.columns = list(subs.columns)
        
        self.dtypes = {}
        self.names = {}
        
        cnts = Counter()

        self.final_dropped_list = []
        
        for v in self.columns:
            name, dtype = self.fixed_types[v]
            
            if dtype is None:
                if name == 'drop':
                    try:
                        subs[v].astype(np.float32)
                        dtype = np.float32
                    except Exception:
                        dtype = np.str

                # сначала проверяем на пустоту и уникальность
                elif subs[v].notnull().sum() == 0 or subs[v].fillna('_null_').drop_duplicates().shape[0] == 1:
                    name = 'drop'
                    dtype = str
                else:
                    name, dtype = get_dtype(subs, v, dateformat = self.datetime_format)
            
          
            if name in ['target', 'line_id', 'group', 'weight']:
                curr_name = name
            else:
                curr_name = name + '_' + str(cnts[name])
                cnts[name] += 1
                
            self.names[v] = curr_name
            
            if name == 'drop':
                self.final_dropped_list.append(curr_name)
            else:
                self.dtypes[curr_name] = dtype


        self.inv_names = {}

        for i in self.names:
            self.inv_names[self.names[i]] = i
        
        return self
    

    
    def transform_names(self, names, fw = True):
        if fw:
            return [self.names[x] for x in names]
        else:
            return [self.inv_names[x] for x in names]
        
    def get_avail_nrows(self, nrows):
        
        if nrows is None:
            nrows = self.rows_limit
        else:
            if self.rows_limit is not None:
                nrows = min(nrows, self.rows_limit)
                
        return nrows
        
    def _read(self, nrows = None, skiprows = None, usecols = None):

        nrows = self.get_avail_nrows(nrows)
        with open(self.last_fname) as f:
            f.seek(self.last_offset)

            if usecols is None:
                usecols = [x for x in self.last_header if not x in self.final_dropped_list]

            data = pd.read_csv(f, header = None, names = self.last_header, 
                               index_col = self.index_col, chunksize = None, 
                           dtype = self.dtypes, nrows = nrows, usecols = usecols,
                           skiprows = skiprows,  squeeze =  False, **self.params
                      ) 
            return data
    
    def _read_chunk(self, nrows = None, skiprows = None, usecols = None, chunksize = 10000):
        
        nrows = self.get_avail_nrows(nrows)
        with open(self.last_fname) as f:
            f.seek(self.last_offset)

            if usecols is None:
                usecols = [x for x in self.last_header if not x in self.final_dropped_list]

            for df in pd.read_csv(f, header = None, names = self.last_header, 
                               index_col = self.index_col, chunksize = chunksize, 
                           dtype = self.dtypes, nrows = nrows, usecols = usecols,
                           skiprows = skiprows,  squeeze =  False, **self.params
                      ): 
                yield df      
                
                
    def _read_mem(self, nrows = None, skiprows = None, usecols = None):
        
        nrows = self.get_avail_nrows(nrows)
        # проверить copy
        data = self.last_fname # .copy()

        if skiprows is not None:
            data = data.set_index(np.arange(len(data)))
            data = data.drop(skiprows, axis = 0)

        if self.index_col is not None:

            data = data.set_index(self.initial_line_id)
            usecols = None if usecols is None else [x for x in usecols if x != 'line_id']

        if nrows is not None:
            data = data[:nrows]

        data = data.rename(columns = self.names, )
        
        if usecols is not None:
            data = data[usecols]# .copy()
        else:
            data = data[[x for x in data.columns if x not in self.final_dropped_list]]# .copy()

        dtype_dict = dict(((x, self.dtypes[x]) for x in self.dtypes if x in data.columns ))

        data = data.astype(dtype_dict)

        return data
    
    
    def _read_chunk_mem(self, nrows = None, skiprows = None, usecols = None, chunksize = 10000):
        
        data = self.read(nrows, skiprows, usecols)
        
        start = range(0, len(data), chunksize)
        stop = range(chunksize, len(data) + chunksize, chunksize)     
            
        for x, y in zip(start, stop):

            yield data[x:y]

            
    def read(self, nrows = None, skiprows = None, usecols = None):
        
        if type(self.last_fname) is str:
            return self._read(nrows, skiprows, usecols)
        else:
            return self._read_mem(nrows, skiprows, usecols)

    
    def read_chunk(self, nrows = None, skiprows = None, usecols = None, chunksize = 10000):      
        
        if type(self.last_fname) is str:
            for df in self._read_chunk(nrows, skiprows, usecols, chunksize):
                yield df
        else:
            for df in self._read_chunk_mem(nrows, skiprows, usecols, chunksize):
                yield df




def read_csv(fb, nrows = None, usecols = None, skiprows = None, squeeze = False):
    
    data = fb.read(nrows = nrows, skiprows = skiprows, usecols = usecols)
    
    if fb.index_col is None:
        data.index.name = 'line_id'
       
    for col in [x for x in data.columns if x[:8] == 'datetime']:
        data[col] = pd.to_datetime(data[col], format = fb.datetime_format).values
    if len(data.columns) == 1 and squeeze:
        return data[data.columns[0]]
    else:
        return data
    
    
    
    
def read_csv_chunk(fb, nrows = None, usecols = None, skiprows = None, chunksize = None, squeeze = False):
    
    for df in fb.read_chunk(nrows = nrows, skiprows = skiprows, usecols = usecols, chunksize = chunksize):

        if fb.index_col is None:
            df.index.name = 'line_id'

        for col in [x for x in df.columns if x[:8] == 'datetime']:
            df[col] = pd.to_datetime(df[col], format = fb.datetime_format).values
        if len(df.columns) == 1 and squeeze:
            df = df[df.columns[0]]
        yield df   
