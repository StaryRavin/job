import pandas as pd
from pandas import Series, DataFrame

import numpy as np
from numpy import random
random.seed(999)

import os

from copy import deepcopy

from .filebuilder import read_csv, read_csv_chunk

class AutoMLDataset():
    
    def __init__(self, fb,task = 'c', max_load_gb_size = 2):
        
        self.task = task

        self.fb = fb
        # self.size = os.stat(fb.last_fname).st_size / (1024 ** 2)
        self.max_load_gb_size = max_load_gb_size
        self.selected_feats = None
        
    def check_memory(self, **kwargs):
        
        if type(self.fb.last_fname) is str:

            try:
                check_rows = kwargs.pop('nrows')
            except KeyError:
                check_rows = self.rows

            _temp_data = self.get_df(nrows = 5, **kwargs)
            memuse = _temp_data.memory_usage().sum() / (1024 ** 2) / (5 / check_rows)
        else:
            memuse = self.fb.last_fname.memory_usage().sum() / (1024 ** 2)
            
        return memuse             
    
    def select_feats(self, feats):
        
        feats = list(feats)
        
        data = read_csv(self.fb, nrows = 2)
        cols = list(data.columns)
        f = []
        for col in cols:
            if col in feats + ['target', 'line_id', 'group', 'weight']:
                f.append(col)
        
        self.selected_feats = f
        self.create_columns_role_basic()
        return self
        
        
    def get_df(self, fb = None, nrows = None, usecols = None, skiprows = None, chunksize = None, test = False, squeeze = False):
        
        if fb is None:
            fb = self.fb
            
        if self.selected_feats is not None and usecols is None:
            
            usecols = deepcopy(self.selected_feats)
            
            if 'target' not in usecols:
                usecols.append('target')
                
            # написать здесь что-то в духе - если тест, то не читай группу и вес fb.last_header
            for _nm in ['group', 'weight']:
                if _nm not in fb.last_header:
                    usecols = [x for x in usecols if x != _nm]
                
            if test == True and fb.last_target == False:
                usecols = [x for x in usecols if x != 'target']
            if fb.index_col is None:
                usecols = [x for x in usecols if x != 'line_id']
            elif 'line_id' not in usecols:
                usecols = list(usecols) + ['line_id']
            
        if chunksize is not None:
            data = read_csv_chunk(fb, nrows = nrows, usecols = usecols, skiprows = skiprows, chunksize = chunksize, squeeze =  squeeze)
        else:
            data = read_csv(fb, nrows = nrows, usecols = usecols, skiprows = skiprows, squeeze =  squeeze)
            
        if skiprows is None and chunksize is None and fb is self.fb and nrows is None:
            self.rows = data.shape[0]
        
        return data
    

        
    def create_target(self):
        if 'target' not in self.__dict__:
            
            usecols = ['target']
            if self.fb.index_col is not None:
                usecols.append(self.fb.index_col)

            self.target = read_csv(self.fb,  usecols = usecols, squeeze =  True)
        self.rows = self.target.shape[0]
        
        # СДЕЛАТЬ ТАК, ЧТОБЫ ТАРГЕТ НЕ ПИКЛИТЬ
        
        return None
    
    
    def drop_target(self):
        if 'target' in self.__dict__:
            del self.target
            gc.collect()
        return None
    

            
    def create_columns_role_basic(self):
        
        dtype_dict = {
    
                'number': 'num', 
                'string': 'cat', 
                'datetime': 'dt', 
                'id': 'id', 
                'target': 'tar',
                'group': 'grp',
                'text': 'txt',
                'weight': 'wgh',

            }
        
        # dummy guessing of data role 
        res = dict((x, []) for x in dtype_dict.values())
        for col in self.fb.dtypes:
            label = col.split('_')[0] 
            if label in dtype_dict:
                if self.selected_feats is not None and col in self.selected_feats or self.selected_feats is None:
                    res[dtype_dict[label]].append(col)
        self.roles = res
        return None
    
    def __getattr__(self, key):
        
        except_list = {'rows': self.create_target,
                       'target': self.create_target,
                       'roles': self.create_columns_role_basic}
        
        if key in except_list:
            if key not in self.__dict__:
                except_list[key]()
        try:
            return self.__dict__[key]
        except KeyError:
            raise AttributeError(key)
