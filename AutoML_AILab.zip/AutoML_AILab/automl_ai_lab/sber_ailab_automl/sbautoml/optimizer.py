from typing import Callable, Union, Tuple

import numpy as np
from scipy.optimize import minimize_scalar
from sklearn import metrics
from sklearn.metrics import mean_squared_error, roc_auc_score

metric_type = Union[None, str, Callable[[np.ndarray, np.ndarray], float]]


class ObjGenerator:

    def __init__(self, reg, gbm, target, task, succes, metric: Tuple[metric_type, bool]):
        """
        Parameters
        ------------
        reg:
           TODO: pass
        gbm:
            TODO: pass
        target:
            TODO: pass
        task:
            TODO: pass
        succes:
            TODO: pass
        metric: metric_type
            TODO: pass
        """
        print(reg.shape)
        print(gbm.shape)

        sl = succes == 1

        self.reg = reg[sl]
        self.gbm = gbm[sl]
        self.y = target[sl]
        self.task = task
        self.metric = self.__get_metric(metric[0]), metric[1]

        self.w = None

    def __get_metric(self, metric: metric_type):
        """
        metric: metric_type
           TODO: pass
        return:
        """
        if metric is None:
            if self.task == "c":
                return roc_auc_score
            else:
                return lambda x, y: np.sqrt(mean_squared_error(x, y))

        elif isinstance(metric, str):
            return getattr(metrics, metric)
        else:
            return metric

    def model_obj(self, w, maximize):
        pred = self.reg * w + self.gbm * (1 - w)
        if maximize:
            return -self.metric[0](self.y, pred)
        else:
            return self.metric[0](self.y, pred)

    def __call__(self, w):
        return self.model_obj(w, self.metric[1])

    def optimize(self):
        res = minimize_scalar(self, bracket=None, bounds=(0, 1), args=(), method='brent', tol=None, options=None)
        print(res)
        self.w = res['x']
        return self
