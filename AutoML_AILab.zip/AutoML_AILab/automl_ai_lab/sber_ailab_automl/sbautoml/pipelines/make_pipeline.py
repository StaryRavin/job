import pandas as pd
from pandas import Series, DataFrame

import numpy as np
from numpy import random
random.seed(999)

import gc
import os


import datetime
from sklearn.pipeline import Pipeline, FeatureUnion


from copy import deepcopy

from .basic import PipelineDF, FeatureSelectorDF, EmptyTransform

from ..transformers.datetime import TimeToNum, TimeToCat, DateDiff
from ..transformers.categorical import HashMeanEncoder, LabelEncoder, GroupByDateEncoder, GroupByEncoder
from ..transformers.numeric import ScalerImputer
from ..transformers.nlp_wrapper.nlp_wrappers import OneToOneTextTransformer, AutomlNLPWrap


from sklearn.preprocessing import OneHotEncoder, PolynomialFeatures, StandardScaler

def make_pipeline_basic(dataset, n_jobs = 1, task = 'r', text_n_jobs = 1):
    
    roles = dataset.roles
    
    feat_pipe = {}
    # prepare dates
    date_cols = dataset.roles['dt']
    if len(date_cols) > 0:
        feat_pipe['dt'] = []
        feat_pipe['dt'].append(('get_dates', FeatureSelectorDF(date_cols)))
        feat_pipe['dt'].append(('time_to_interval', TimeToNum()))
        
        feat_pipe['dt'] = PipelineDF(feat_pipe['dt'])
        
        
        
    # prepare cats
    cat_cols = dataset.roles['cat'] + dataset.roles['id']
    if len(cat_cols) > 0:
        feat_pipe['cat'] = []
        feat_pipe['cat'].append(('get_cats', FeatureSelectorDF(cat_cols)))
        feat_pipe['cat'].append(('hash_cats', LabelEncoder()))
        
        feat_pipe['cat'] = PipelineDF(feat_pipe['cat'])
        
    num_cols = roles['num'] 
    if len(num_cols) > 0:
        feat_pipe['num'] = []
        feat_pipe['num'].append(('get_nums', FeatureSelectorDF(num_cols)))
        
        feat_pipe['num'] = PipelineDF(feat_pipe['num'])
        
    #######
    # text pipeline simple
    
    text_cols = roles['txt']
    if len(text_cols) > 0:
        for col in text_cols:
            feat_pipe['text_' + col] = []
            feat_pipe['text_' + col].append(('get_text', FeatureSelectorDF([col])))
            feat_pipe['text_' + col].append(('text_score', OneToOneTextTransformer(n_jobs = 1, task = task)))     
            
            feat_pipe['text_' + col] = PipelineDF(feat_pipe['text_' + col])

    #######    
    
        
    union = [] 
    for i in feat_pipe:
        union.append((i, feat_pipe[i]))

    pipe = FeatureUnion(union, n_jobs = n_jobs)
    
    pipe = PipelineDF([
        
                         ('features', pipe)
        
                            ])
    # prepare ids
    
    return pipe
        
def check_line_order(dataset):
    
    ind = dataset.target.index.values
    ind = ind[1:] - ind[:-1]
    flg = (ind == 1).all()
    
    return flg


def select_kw(fs, kw, n = 5):
    return [x.split('__')[1] for x in fs if kw in x][:n]


def make_pipeline_middle(dataset, fs, cat_co = 20, subsamp = 10000, n_jobs = 1, use_ids = False,
                        text_n_jobs = 1, embedding = None, config = None
                        ):
    
    # get small subsamp
    cnt_rows = dataset.rows
    idx = np.sort(random.choice(np.arange(cnt_rows, dtype = np.int32), size = max(0, cnt_rows - subsamp), replace = False))
    check_df = dataset.get_df(skiprows = idx)
    
    roles = dataset.roles
    
    feat_pipe = {}
    # prepare dates
    date_cols = dataset.roles['dt']
    if len(date_cols) > 0:
        feat_pipe['dt'] = []
        feat_pipe['dt'].append(('get_dates', FeatureSelectorDF(date_cols)))
        feat_pipe['dt'].append(('time_to_interval', TimeToCat()))
        
        feat_pipe['dt'] = PipelineDF(feat_pipe['dt'])
        
    
    dsel = [x for x in select_kw(fs, 'datetime', n = 5) if x in date_cols]
    if len(dsel) > 1:
        feat_pipe['dt_i'] = []
        feat_pipe['dt_i'].append(('get_dates', FeatureSelectorDF(dsel)))
        feat_pipe['dt_i'].append(('time_to_interval',  DateDiff()))
        
        feat_pipe['dt_i'] = PipelineDF(feat_pipe['dt_i'])    
        
        
    # prepare cats
    cat_cols = dataset.roles['cat'] + dataset.roles['num'] # + dataset.roles['id'] 
    
    cat_oof, cat_enc = [], []
    for i in cat_cols:
        un = check_df[i].nunique(dropna = False)
        nfl = (i in dataset.roles['num'])
        if (nfl and 2 < un < 10) or not nfl:
            if nfl:
                print(i, 'casted as category')
            if un > cat_co:
                print(i, 'goes to oof')
                cat_oof.append(i)
            elif dataset.task == 'r' or not nfl:
                cat_enc.append(i)
    
    if len(cat_enc) > 0:
        feat_pipe['cat'] = []
        feat_pipe['cat'].append(('get_cats', FeatureSelectorDF(cat_enc)))
        feat_pipe['cat'].append(('hash_cats', LabelEncoder()))
        
        feat_pipe['cat'] = PipelineDF(feat_pipe['cat'])
        
    if len(cat_oof) > 0:
        for i in cat_oof:
            feat_pipe['oof_' + i] = []
            feat_pipe['oof_' + i].append(('get_cat_' + i, FeatureSelectorDF([i])))
            feat_pipe['oof_' + i].append(('hash_cats', HashMeanEncoder(name = i, task = dataset.task)))

            feat_pipe['oof_' + i] = PipelineDF(feat_pipe['oof_' + i])        
        
    # the rest are nums
    num_cols = [x for x in roles['num']  
               ]
    if len(num_cols) > 0:
        feat_pipe['num'] = []
        feat_pipe['num'].append(('get_nums', FeatureSelectorDF(num_cols)))
        
        feat_pipe['num'] = PipelineDF(feat_pipe['num'])
        
        
    #######
    # text pipeline
    text_cols = roles['txt']
    if len(text_cols) > 0:
        for col in text_cols:
            feat_pipe['text_' + col] = []
            feat_pipe['text_' + col].append(('get_text', FeatureSelectorDF([col])))
            feat_pipe['text_' + col].append(('text_score', AutomlNLPWrap(embed_model = embedding, n_jobs = text_n_jobs, config = config)))     
            
            feat_pipe['text_' + col] = PipelineDF(feat_pipe['text_' + col])
    
    

    #######
    ids = ids = dataset.roles['id']

    if use_ids:
        for i in ids:
            for n in num:
                feat_pipe['enc_' + i + n] = []
                feat_pipe['enc_' + i + n].append(('sel', FeatureSelectorDF([i, n])))
                feat_pipe['enc_' + i + n].append(('enc', GroupByEncoder(by = [i], feat = n)))
                feat_pipe['enc_' + i + n].append(('scale_impute', ScalerImputer()))

                feat_pipe['enc_' + i + n] = PipelineDF(feat_pipe['enc_' + i + n])
    
        
    union = [] 
    for i in feat_pipe:
        union.append((i, feat_pipe[i]))

    pipe = FeatureUnion(union, n_jobs = n_jobs)
    
    pipe = PipelineDF([
                       
                         ('features', pipe)
                       
                        ])
    # prepare ids
    
    return pipe


def make_pipeline_reg(dataset, fs, cat_co = 20, subsamp = 10000, use = True, use_ids = False, text_n_jobs = 1, embedding = None, config = None):
    
    # get small subsamp
    cnt_rows = dataset.rows
    idx = np.sort(random.choice(np.arange(cnt_rows, dtype = np.int32), size = max(0, cnt_rows - subsamp), replace = False))
    check_df = dataset.get_df(skiprows = idx)
    
    roles = dataset.roles
    
    feat_pipe = {}
    # prepare dates
    date_cols = dataset.roles['dt']
    if use:
        if len(date_cols) > 0:
            feat_pipe['dt'] = []
            feat_pipe['dt'].append(('get_dates', FeatureSelectorDF(date_cols)))
            feat_pipe['dt'].append(('time_to_interval', TimeToCat(day_bin = 3)))
            feat_pipe['dt'].append(('hash_cats', LabelEncoder()))
            feat_pipe['dt'].append(('ohe', OneHotEncoder(sparse = True, handle_unknown = 'ignore', dtype = np.float32)))
            
            feat_pipe['dt'] = PipelineDF(feat_pipe['dt'])
    
    dsel = [x for x in select_kw(fs, 'datetime', n = 5) if x in date_cols]    
    print(dsel)
    
    if use:
        if len(dsel) > 1:
            feat_pipe['dt_i'] = []
            feat_pipe['dt_i'].append(('get_dates', FeatureSelectorDF(dsel)))
            feat_pipe['dt_i'].append(('time_to_interval', DateDiff()))
            feat_pipe['dt_i'].append(('scale_impute', ScalerImputer()))
            
            feat_pipe['dt_i'] = PipelineDF(feat_pipe['dt_i'])    
        
        
    # prepare cats
    if use:
        cat_cols = dataset.roles['cat'] 
        if len(cat_cols) > 0:
            feat_pipe['cat'] = []
            feat_pipe['cat'].append(('get_cats', FeatureSelectorDF(cat_cols)))
            feat_pipe['cat'].append(('hash_cats', LabelEncoder()))
            feat_pipe['cat'].append(('ohe', OneHotEncoder(sparse = True, handle_unknown = 'ignore', dtype = np.float32)))
            
            feat_pipe['cat'] = PipelineDF(feat_pipe['cat'])
        
    
    ids = select_kw(fs, 'id', n = 2)  
    dt = select_kw(fs, 'datetime', n = 2)  
    num = select_kw(fs, 'number', n = 2)  

    ids = dataset.roles['id'] 
    if use_ids and use:
        if len(ids) > 0:
            for i in ids:
                feat_pipe['oof_' + i] = []
                feat_pipe['oof_' + i].append(('get_cat_' + i, FeatureSelectorDF([i])))
                feat_pipe['oof_' + i].append(('hash_cats', HashMeanEncoder(name = i, task = dataset.task)))

                feat_pipe['oof_' + i] = PipelineDF(feat_pipe['oof_' + i])        

    if use:
        pass
        #######
        # text pipeline
        text_cols = roles['txt']
        if len(text_cols) > 0:
            for col in text_cols:
                feat_pipe['text_' + col] = []
                feat_pipe['text_' + col].append(('get_text', FeatureSelectorDF([col])))
                feat_pipe['text_' + col].append(('text_score', AutomlNLPWrap(embed_model = embedding, n_jobs = text_n_jobs, config = config)))     

                feat_pipe['text_' + col] = PipelineDF(feat_pipe['text_' + col])


        #######


    # the rest are nums
    if use:
        num_cols = [x for x in roles['num']] 
    else:
        num_cols = select_kw(fs, 'number', n = 10)  
               
    if len(num_cols) > 0:
        feat_pipe['num'] = []
        feat_pipe['num'].append(('get_nums', FeatureSelectorDF(num_cols)))
        feat_pipe['num'].append(('scale_impute', ScalerImputer()))
        
        
        feat_pipe['num'] = PipelineDF(feat_pipe['num'])



        
    union = [] 
    for i in feat_pipe:
        union.append((i, feat_pipe[i]))

    pipe = FeatureUnion(union)
    

    steps = [
        
                     ('features', pipe)
        
                    ]

    pipe = PipelineDF(steps)
    # prepare ids
    
    return pipe
        
        