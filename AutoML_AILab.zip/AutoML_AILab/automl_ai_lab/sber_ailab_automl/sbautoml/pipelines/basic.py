import pandas as pd
from pandas import Series, DataFrame

import numpy as np
from numpy import random
random.seed(999)

import gc

import os


import datetime
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.utils import murmurhash3_32
from sklearn.linear_model import SGDClassifier, SGDRegressor
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.model_selection import StratifiedKFold, KFold, cross_val_predict

from copy import deepcopy


class FeatureSelectorDF(TransformerMixin, BaseEstimator):
    
    def __init__(self, keys = []):
        super().__init__()
        self.keys = keys
        
    
    def fit(self, X, y = None):
        
        return self
    
    def transform(self, X, y = None):
        
        keys = [x for x in self.keys if x in X.columns]
        
        self.feature_names = keys
        
        return X[keys]
    
    def get_feature_names(self):
        
        return self.feature_names
        
        
class EmptyTransform(TransformerMixin, BaseEstimator):
    
    def fit(self, X, y = None):
        
        return self
    
    def transform(self, X, y = None):
        
        self.feature_names = list(X.columns)
        
        return X
        
        
    def get_feature_names(self):
        
        return self.feature_names
    


class PipelineDF(Pipeline):
    
    def __init__(self, steps, memory=None):
        self.last_step = steps[-1][0]
        super().__init__(steps, memory)
        
    
    def get_feature_names(self):
        return self.named_steps[self.last_step].get_feature_names()
    


