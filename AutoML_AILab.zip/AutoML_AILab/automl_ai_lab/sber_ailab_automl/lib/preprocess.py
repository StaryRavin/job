import copy
import datetime
import warnings
import numpy as np
import pandas as pd
from sklearn.exceptions import DataConversionWarning
from .util import timeit, log, Config


@timeit
def preprocess(df: pd.DataFrame, config: Config):
    preprocess_pipeline(df, config)


def preprocess_pipeline(df: pd.DataFrame, config: Config):
    drop_columns(df, config)
    non_negative_target_detect(df, config)


@timeit
def drop_columns(df: pd.DataFrame, config: Config):
    df.drop([c for c in ["line_id"] if c in df], axis=1, inplace=True)
    drop_constant_columns(df, config)

@timeit
def drop_constant_columns(df: pd.DataFrame, config: Config):
    if "constant_columns" not in config:
        config["constant_columns"] = [c for c in df if c.startswith("number_") and not (df[c] != df[c].iloc[0]).any()]
        log("Constant columns: " + ", ".join(config["constant_columns"]))

    if len(config["constant_columns"]) > 0:
        df.drop(config["constant_columns"], axis=1, inplace=True)

@timeit
def non_negative_target_detect(df: pd.DataFrame, config: Config):
    if config.is_train():
        config["non_negative_target"] = df["target"].lt(0).sum() == 0

