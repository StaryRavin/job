import pandas as pd
from pandas import Series, DataFrame
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, roc_auc_score
from sklearn import metrics
from typing import List
from sklearn.model_selection import StratifiedKFold, KFold, GroupKFold
from copy import deepcopy

from .util import timeit, log, Config, GroupKFoldSeed, feval_deco_common, StratifiedGroupKFold

import gc


cl_params = {
    'task': 'train',
    'boosting_type': 'gbdt',
    'objective': 'binary',
    'metric': 'auc',
    "learning_rate": 0.05,
    "num_leaves": 128,
    "feature_fraction": 0.70,
    "bagging_fraction": 0.70,
    'bagging_freq': 1,
    "max_depth": -1,
    "verbosity": -1,
    "reg_alpha": 1,
    "reg_lambda": 0.0,
    "min_split_gain": 0.0,
    "min_child_weight": 0,
    'zero_as_missing': False,
    'num_threads': 4,
    'max_bin': 255,
    'min_data_in_bin': 3,
    "seed": 1
}

reg_params = {
    'task': 'train',
    'boosting_type': 'gbdt',
    'objective': 'regression',
    'metric': 'rmse',
    "learning_rate": 0.05,
    "num_leaves": 32,
    "feature_fraction": 0.9,
    "bagging_fraction": 0.9,
    'bagging_freq': 1,
    "max_depth": -1,
    "verbosity": -1,
    "reg_alpha": 1,
    "reg_lambda": 0,
    "min_split_gain": 0.0,
    "min_child_weight": 0,
    'zero_as_missing': False,
    'num_threads': 4,
    'max_bin': 255,
    'min_data_in_bin': 3,
    "seed": 1
}


@timeit
def get_initial_params(dataset, VCPU_LIMIT):
    if dataset.rows <= 20000:
        init_lr = 0.005
        # ntrees = 5000
        # es = 200

    elif dataset.rows <= 100000:
        init_lr = 0.01
        # ntrees = 1200
        # es = 200
    elif dataset.rows <= 300000:
        init_lr = 0.025
        # ntrees = 2000
        # es = 100
    else:
        init_lr = 0.025
        # ntrees = 2000
        # es = 100
    #####################
    # manual tune params
    params = deepcopy(reg_params) if dataset.task == 'r' else deepcopy(cl_params)

    if dataset.rows > 300000:
        params['num_leaves'] = 64 if dataset.task == 'r' else 244
    elif dataset.rows > 100000:
        params['num_leaves'] = 64 if dataset.task == 'r' else 128
    elif dataset.rows > 50000:
        params['num_leaves'] = 32 if dataset.task == 'r' else 64
        # params['reg_alpha'] = 1 if dataset.task == 'r' else 0.5 
    elif dataset.rows > 20000:
        params['num_leaves'] = 32 if dataset.task == 'r' else 32
        params['reg_alpha'] = 0.5 if dataset.task == 'r' else 0.0
    elif dataset.rows > 10000:
        params['num_leaves'] = 32 if dataset.task == 'r' else 64
        params['reg_alpha'] = 0.5 if dataset.task == 'r' else 0.2
    elif dataset.rows > 5000:
        params['num_leaves'] = 24 if dataset.task == 'r' else 32
        params['reg_alpha'] = 0.5 if dataset.task == 'r' else 0.5
    else:
        params['num_leaves'] = 16 if dataset.task == 'r' else 16
        params['reg_alpha'] = 1 if dataset.task == 'r' else 1

    train_params = deepcopy(params)
    train_params['learning_rate'] = init_lr
    train_params['num_threads'] = VCPU_LIMIT
    return train_params


@timeit
def train(X: pd.DataFrame, y: pd.Series, config: Config, group=None, weight = None):
    # if "leak" in config:
    #     return

    oof_pred, succes = train_lightgbm(X, y, config, group, weight)
    return oof_pred, succes


@timeit
def predict(X: pd.DataFrame, config: Config) -> List:
    # if "leak" in config:
    #     preds = predict_leak(X, config)
    # else:
    preds = predict_lightgbm(X, config)
    if config["non_negative_target"]:
        preds = [max(0, p) for p in preds]

    return preds


@timeit
def validate(preds: pd.DataFrame, target_csv: str, mode: str) -> np.float64:
    df = pd.merge(preds, pd.read_csv(target_csv), on="line_id", left_index=True)
    score = roc_auc_score(df.target.values, df.prediction.values) if mode == "classification" else \
        np.sqrt(mean_squared_error(df.target.values, df.prediction.values))  # TODO: Add validate for custom metric
    log("Score: {:0.4f}".format(score))
    return score


@timeit
def train_lightgbm(X: pd.DataFrame, y: pd.Series, config: Config, group, weight):
    K = 10
    hyperparams = get_initial_params(config["aml_dataset"], config['vCPU_limit'])

    maximize = config["metric"][1]  # False if config["mode"] == 'regression' else True
    if config["metric"][0] is None:
        feval_func = None
    else:
        hyperparams["metric"] = "None"
        if isinstance(config["metric"][0], str):
            feval_func = feval_deco_common("lgb", maximize)(getattr(metrics, config["metric"][0]))
        else:
            feval_func = feval_deco_common("lgb", maximize)(config["metric"][0])

    if group is not None:
        sgr = Series(group)
        assert sgr.isnull().any() == False, 'Group contains NaN'
        if config["mode"] == 'regression':
            kf = GroupKFoldSeed(n_splits=min(config['KFolds'], sgr.nunique()),
                                random_state=config['cv_random_state']).split(group.values, group.values, group.values)
        else:
            stratified_group_k_fold = StratifiedGroupKFold()
            kf = stratified_group_k_fold(group, y, group, k=min(config['KFolds'], sgr.nunique()), seed = config['cv_random_state'])

    else:
        if config["mode"] == 'regression':
            kf = KFold(n_splits=config['KFolds'], random_state=config['cv_random_state'], shuffle=True).split(X, y)
        else:
            kf = StratifiedKFold(n_splits=config['KFolds'], random_state=config['cv_random_state'], shuffle=True).split(
                X, y)
    print('WE ARE USING CV_RANDOM_STATE = {}'.format(config['cv_random_state']))
    config.write_to_logfile('WE ARE USING CV_RANDOM_STATE = {}'.format(config['cv_random_state']))

    models = []
    folds_time = np.array([0.0] * K)

    oof_pred = np.zeros_like(y, dtype=np.float32)
    succes = np.zeros_like(y, dtype=np.float32)

    print('LGBM MODELS PARAMS = {}, MAX_NUM_TREES = {}, EARLY_STOPPING_ROUNDS = {}'.format(hyperparams, 3000, 50))
    config.write_to_logfile(
        'LGBM MODELS PARAMS = {}, MAX_NUM_TREES = {}, EARLY_STOPPING_ROUNDS = {}'.format(hyperparams, 3000, 50))
    for i, (train_index, test_index) in enumerate(kf):
        start_time = config.time_left()
        y_train, y_valid = y.values[train_index], y.values[test_index]
        X_train, X_valid = X.values[train_index, :], X.values[test_index, :]
        log("Fold {} ".format(i) + '=' * 90)
        if group is not None:
            print('Intersection', len(set(group.values[train_index]).intersection(set(group.values[test_index]))))
        else:
            print('No groups')

        train_data = lgb.Dataset(X_train, label=y_train, categorical_feature=config["aml_cats"],
                                 feature_name=config["aml_feats"], weight =  None if weight is None else  weight.values[train_index]
                                 )
        valid_data = lgb.Dataset(X_valid, label=y_valid, categorical_feature=config["aml_cats"],
                                 feature_name=config["aml_feats"], weight =  None if weight is None else  weight.values[test_index]
                                 )

        model = lgb.train(hyperparams, train_data, 3000, valid_data, categorical_feature=config["aml_cats"],
                          feature_name=config["aml_feats"],
                          feval=feval_func,
                          early_stopping_rounds=50, verbose_eval=100, keep_training_booster=False)

        models.append(model)
        oof_pred[test_index] = model.predict(X_valid)
        succes[test_index] = 1

        if config["metric"][0] is None:
            if config["mode"] == 'regression':
                print(
                    "FOLD = {}, LGBM_RMSE_SCORE = {}".format(i, np.sqrt(mean_squared_error(y_valid, oof_pred[test_index]))))
                config.write_to_logfile(
                    "FOLD = {}, LGBM_RMSE_SCORE = {}".format(i, np.sqrt(mean_squared_error(y_valid, oof_pred[test_index]))))
            else:
                print("FOLD = {}, LGBM_AUC_SCORE = {}".format(i, roc_auc_score(y_valid, oof_pred[test_index])))
                config.write_to_logfile(
                    "FOLD = {}, LGBM_AUC_SCORE = {}".format(i, roc_auc_score(y_valid, oof_pred[test_index])))

        elif isinstance(config["metric"][0], str):
            print(
                "FOLD = {}, LGBM_{} = {}".format(i, config["metric"][0],
                                                 getattr(metrics, config["metric"][0])(y_valid, oof_pred[test_index])))
            config.write_to_logfile(
                "FOLD = {}, LGBM_{} = {}".format(i, config["metric"][0],
                                                 getattr(metrics, config["metric"][0])(y_valid, oof_pred[test_index])))
        else:
            print(
                "FOLD = {}, LGBM_{} = {}".format(i, config["metric"][0].__name__,
                                                 config["metric"][0](y_valid, oof_pred[test_index])))
            config.write_to_logfile(
                "FOLD = {}, LGBM_{} = {}".format(i, config["metric"][0].__name__,
                                                 config["metric"][0](y_valid, oof_pred[test_index])))

        del train_data, valid_data
        gc.collect()

        t_left = config.time_left()
        folds_time[i] = start_time - t_left
        if t_left / np.mean(folds_time[0:i + 1]) < 1.2:
            break

    ####################
    config["model"] = models
    return oof_pred, succes


@timeit
def predict_lightgbm(X: pd.DataFrame, config: Config) -> List:
    for i in range(len(config["model"])):
        if i == 0:
            res = config["model"][0].predict(X)
        else:
            res += config["model"][i].predict(X)
    return res / len(config["model"])


def data_split(X: pd.DataFrame, y: pd.Series, test_size: float = 0.2, rs: int = 1) -> (
pd.DataFrame, pd.Series, pd.DataFrame, pd.Series):
    return train_test_split(X, y, test_size=test_size, random_state=rs)
