import datetime
import time
from copy import deepcopy, copy
from typing import Any
from typing import Callable, Union

import numpy as np
from sklearn.model_selection import GroupKFold
from sklearn.utils import check_array
from sklearn import metrics

from ..sbautoml.transformers.nlp_wrapper.nlp_wrappers import model_path  as mystem_path
from ..sbautoml.transformers.nlp_wrapper.text_tokenizer import Tokenizer
from collections import Counter, defaultdict
import random as rndm

class GroupKFoldSeed(GroupKFold):
    
    def __init__(self, n_splits, random_state = None):
        super().__init__(n_splits)
        self.random_state = random_state
        
    def _iter_test_indices(self, X, y, groups):
        if groups is None:
            raise ValueError("The 'groups' parameter should not be None.")
        groups = check_array(groups, ensure_2d=False, dtype=None)

        unique_groups, groups = np.unique(groups, return_inverse=True)
        n_groups = len(unique_groups)

        if self.n_splits > n_groups:
            raise ValueError("Cannot have number of splits n_splits=%d greater"
                             " than the number of groups: %d."
                             % (self.n_splits, n_groups))

        # Weight groups by their number of occurrences
        n_samples_per_group = np.bincount(groups)

        # Distribute the most frequent groups first
        indices = np.argsort(n_samples_per_group)[::-1]
        # shuffle indices by axis 0
        np.random.seed(self.random_state)
        for start, stop in zip(range(0, indices.shape[0], self.n_splits), 
                               range(self.n_splits, indices.shape[0] + self.n_splits, self.n_splits)):
            np.random.shuffle(indices[start:stop])
        # continue ...
        n_samples_per_group = n_samples_per_group[indices]

        # Total weight of each fold
        n_samples_per_fold = np.zeros(self.n_splits)

        # Mapping from group index to fold index
        group_to_fold = np.zeros(len(unique_groups))

        # Distribute samples by adding the largest weight to the lightest fold
        for group_index, weight in enumerate(n_samples_per_group):
            lightest_fold = np.argmin(n_samples_per_fold)
            n_samples_per_fold[lightest_fold] += weight
            group_to_fold[indices[group_index]] = lightest_fold

        indices = group_to_fold[groups]

        for f in range(self.n_splits):
            yield np.where(indices == f)[0]
            
            
class StratifiedGroupKFold():
    
    def __init__(self, ):
        
        self.groups = None
        self.groups_per_fold = None
    
    def __call__(self, X, y, groups, k, seed=None):
        
        if self.groups is None:
        
            y = y.astype(int)
            labels_num = np.max(y) + 1
            y_counts_per_group = defaultdict(lambda: np.zeros(labels_num))
            y_distr = Counter()
            for label, g in zip(y, groups):
                y_counts_per_group[g][label] += 1
                y_distr[label] += 1

            y_counts_per_fold = defaultdict(lambda: np.zeros(labels_num))
            groups_per_fold = defaultdict(set)

            def eval_y_counts_per_fold(y_counts, fold):
                y_counts_per_fold[fold] += y_counts
                std_per_label = []
                for label in range(labels_num):
                    label_std = np.std([y_counts_per_fold[i][label] / y_distr[label] for i in range(k)])
                    std_per_label.append(label_std)
                y_counts_per_fold[fold] -= y_counts
                return np.mean(std_per_label)

            groups_and_y_counts = list(y_counts_per_group.items())
            rndm.Random(seed).shuffle(groups_and_y_counts)

            for g, y_counts in sorted(groups_and_y_counts, key=lambda x: -np.std(x[1])):
                best_fold = None
                min_eval = None
                for i in range(k):
                    fold_eval = eval_y_counts_per_fold(y_counts, i)
                    if min_eval is None or fold_eval < min_eval:
                        min_eval = fold_eval
                        best_fold = i
                y_counts_per_fold[best_fold] += y_counts
                groups_per_fold[best_fold].add(g)
                
            self.groups = groups
            self.groups_per_fold = groups_per_fold

        all_groups = set(self.groups)
        for i in range(k):
            train_groups = all_groups - self.groups_per_fold[i]
            test_groups = self.groups_per_fold[i]

            train_indices = [i for i, g in enumerate(self.groups) if g in train_groups]
            test_indices = [i for i, g in enumerate(self.groups) if g in test_groups]

            yield train_indices, test_indices

nesting_level = 0
is_start = None


def timeit(method):
    def timed(*args, **kw):
        global is_start
        global nesting_level

        if not is_start:
            print()

        is_start = True
        log("Start {}.".format(method.__name__))
        nesting_level += 1

        start_time = time.time()
        result = method(*args, **kw)
        end_time = time.time()

        nesting_level -= 1
        log("End {}. Time: {:0.2f} sec.".format(method.__name__, end_time - start_time))
        is_start = False

        return result

    return timed


def log(entry: Any):
    global nesting_level
    space = "." * (4 * nesting_level)
    print("{}{}".format(space, entry))


def save_tokenizer(state):
    for pipe in ['aml_pipe', 'aml_reg_pipe']:
        for name, tr in state[pipe].named_steps['features'].transformer_list:

            if name[:5] == 'text_':

                print(tr.named_steps['text_score'])
                trnf = tr.named_steps['text_score']

                tok_params = trnf.tokenizer.__dict__
                tok_params.pop('mystem')
                trnf.tokenizer = tok_params

    return None


def load_tokenizer(state):
    for pipe in ['aml_pipe', 'aml_reg_pipe']:
        for name, tr in state[pipe].named_steps['features'].transformer_list:

            if name[:5] == 'text_':
                trnf = tr.named_steps['text_score']

                temp_params = deepcopy(trnf.tokenizer)
                st = temp_params.pop('stemmer')
                if st is not None:
                    temp_params['use_stemmer'] = True
                else:
                    temp_params['use_stemmer'] = False

                trnf.tokenizer = Tokenizer(mystem_path = mystem_path, **temp_params)
    return None

    
class Config:
    def __init__(self, cache_dir = None, vCPULimit = 4, memoryLimit = 12, timeLimit = 300, encoding = 'utf-8', separator = ',', 
                       decimal = b'.', datetime_format = None, na_values = None, analyze_rows = 100, embeddings_path = None,
                       use_gpu = True, test_batch_size = 10000, cv_random_state = 13, KFolds = 10, log_file = None, featureSelParams = (None, 1, True), metric: Union[str, Callable[[np.ndarray, np.ndarray], float]] = None):

        self.data = {
            "cache_dir": cache_dir,
            "start_time": time.time(),
            "time_limit": timeLimit,
            "vCPU_limit": vCPULimit,
            "memory_limit": memoryLimit,
            "encoding": encoding,
            "separator": separator,
            "decimal": decimal,
            "datetime_format": datetime_format,
            "na_values": na_values,
            "analyze_rows": analyze_rows,
            "log_file": log_file,
            "embeddings_path": embeddings_path,
            "use_gpu": use_gpu,
            "test_batch_size": test_batch_size,
            "cv_random_state": cv_random_state,
            "KFolds": KFolds,
            "featureSelParams": featureSelParams,
            "isTrained": False,
            "metric": (metric, self.__metric(metric)),
        }
        print('AUTOML_CONFIG = {}'.format(self.data))

    @staticmethod
    def __metric(metric):
        y_true = [1, 0, 1]
        y_pred = [1, 0, 0]
        if metric is not None:
            if isinstance(metric, str):
                metric_ = getattr(metrics, metric)
                ideal_score = metric_(y_true, y_true)
                not_ideal_score = metric_(y_true, y_pred)
            else:
                ideal_score = metric(y_true, y_true)
                not_ideal_score = metric(y_true, y_pred)

            if ideal_score > not_ideal_score:
                return True
            else:
                return False

    def is_train(self) -> bool:
        return self["task"] == "train"

    def is_predict(self) -> bool:
        return self["task"] == "predict"

    def is_regression(self) -> bool:
        return self["mode"] == "regression"

    def is_classification(self) -> bool:
        return self["mode"] == "classification"

    def time_left(self):
        return self["time_limit"] - (time.time() - self["start_time"])

    def get_train_time(self):
        return time.time() - self["start_time"]

    def write_to_logfile(self, s):
        if self['log_file']:
            with open(self['log_file'], 'a') as logfile:
                logfile.write(str(datetime.datetime.now()) + ' ' + s + '\n')

    def __getitem__(self, key):
        return self.data[key]

    def __setitem__(self, key, value):
        self.data[key] = value

    def __delitem__(self, key):
        del self.data[key]

    def __contains__(self, key):
        return key in self.data

    def __len__(self):
        return len(self.data)

    def __repr__(self):
        return repr(self.data)

    def __getstate__(self, ):
        state = copy(self.data)
        save_tokenizer(state)
        return state
    
    def __setstate__(self, state):
        self.data = state
        print(self.data.keys())
        load_tokenizer(self.data)
        return None


def feval_deco_common(lib="lgb", maximize=None):
    """
    lib: str
       alias of library used
    :return:
    """
    def feval_deco(metric_function: Callable[[np.ndarray, np.ndarray], float]) -> Callable:
        """

        metric_function: metric function
        :return:
        """
        def feval_func(pred, train_data):
            """
            pred:
                TODO:
            train_data:
                TODO:
            :return:
            """
            if lib == "lgb":
                return metric_function.__name__, metric_function(train_data.get_label(), pred), maximize
            elif lib == "xgb":
                return metric_function.__name__, metric_function(train_data.get_label(), pred)
        return feval_func
    return feval_deco




