from sklearn.base import BaseEstimator, ClassifierMixin, RegressorMixin
import pandas as pd
from pandas import Series, DataFrame
from copy import copy, deepcopy
from .automl import AutoML
import numpy as np

class SAAEstimator(BaseEstimator):
    
    def __init__(self, mode, data_roles = {}, feature_names = None, cache_dir = None, n_jobs = 1, automl = None, **kwargs):
        
        assert 'target' not in data_roles, 'Target is passed on fit stage'
        kwargs = deepcopy(kwargs)

        super().__init__()
        self.mode = mode
        self.cache_dir = cache_dir
        self.data_roles = data_roles
        self.n_jobs = n_jobs
        self.feature_names = feature_names
        self. automl = AutoML(**kwargs) if automl is None else automl
        
    
    def _preprocess(self, X, y = None, data_roles = None):
        
        if type(X) is np.ndarray:
            if self.feature_names is None:
                X = DataFrame(X, columns = ['var_' + str(x) for x in range(X.shape[1])])
                if data_roles is not None:
                    for k in data_roles:
                        if type(data_roles[k]) not in [str, int] :
                            data_roles[k] = ['var_' + str(x) for x in data_roles[k]] 
                        elif type(data_roles[k]) is int :
                            data_roles[k] = 'var_' + str(data_roles[k])
                        else:
                            raise ValueError('Wrong data roles dict format')
            else:
                X = DataFrame(X, columns = self.feature_names)
        elif type(X) is DataFrame:
            X = X.copy()
        
        # write target
        if y is not None:
            name = 'target'
            n = 0
            while True:
                if name in X.columns:
                    name = 'target' + str(n)
                    n += 1
                else:
                    X[name] = y
                    if data_roles is not None:
                        data_roles['target'] = name
                    break
                    
        return X, data_roles
        
    
    def fit(self, X, y):
        
        data_roles = deepcopy(self.data_roles)
        
        X, data_roles = self._preprocess(X, y, data_roles)
        
        self.automl.train(X, data_roles, self.mode, self.cache_dir, use_ids = False)
        return self
    
    def predict(self, X):
        
        X, _ = self._preprocess(X, )
        result, _, __ = self.automl.predict(X, n_jobs = self.n_jobs)
        return result['prediction'].values
    """
    def __getstate__(self):
        return self.automl

    def __setstate__(self, state):
        self.automl = state
    """

    def set_params(self, **kwargs):
        for k in kwargs.keys():
            self.__dict__[k] = kwargs[k]

        
class SAARegressor(SAAEstimator, RegressorMixin):
    
    def __init__(self, **kwargs):
        super().__init__(mode = 'regression', **kwargs)

    
class SAAClassifier(SAAEstimator, ClassifierMixin):  

    def __init__(self, co = 0.5, return_prob = False, **kwargs):
        super().__init__(mode = 'classification', **kwargs) 
        super(ClassifierMixin).__init__()
        self.co = co
        self.return_prob = return_prob
    
    def predict_proba(self, X):
        X_ = super().predict(X)
        return np.stack([1 - X_, X_], axis = 1)
    
    def set_co(self, co):
        self.co = co
    
    def predict(self, X):
        X_ = super().predict(X)
        if self.return_prob:
            return X_
        X_ = (X_ > self.co).astype(np.int32)
        return X_
