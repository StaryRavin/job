import os
import sys
sys.path.append('..')

import pandas as pd
from pandas import Series, DataFrame
import numpy as np
# from .util import timeit, Config
from .preprocess import preprocess
from .model import train, predict, validate


from ..sbautoml.reader import get_pred_iterator, get_train_df_w_reg, get_pred_iterator_reg
from sklearn.metrics import mean_squared_error, roc_auc_score

import gc




def get_filelen(fname, encoding):
    
    if type(fname) is not str:
        return fname.shape[0]

    cnt_lines = -1
    with open(fname, 'r', encoding = encoding) as fin:
        for line in fin:
            if len(line.strip()) > 0:
                cnt_lines += 1    
    return cnt_lines
    

def predict_on_filebuilder(config, offset = None, chunksize = None, verbose = True, ):
    result = {
            "line_id": [],
            "prediction": [],
            "reg": [],
            "gbm": [],
            "target": []
        }
        
    config["fileb"].set_rows_limit(limit = chunksize, offset = offset)


    cnt_lines =  get_filelen(config["fileb"].last_fname, config['encoding']) if chunksize is None else chunksize
    batch_cnt = int(np.ceil(cnt_lines / config["test_batch_size"]))  

    # predict lgbm
    for it, X in enumerate(get_pred_iterator(config["aml_dataset"], config["fileb"],  config["aml_pipe"], config["test_batch_size"])):
        print('LGBM BATCH {}/{} '.format(it + 1, batch_cnt) + '=' * 90)
        result["line_id"] += list(X["line_id"])

        if 'target' in X.columns:
            result["target"] += list(X["target"])

        preprocess(X, config)
        preds = list(predict(X, config))
        result["gbm"] += list(preds)

    config.write_to_logfile('Построение предсказания LGBM')

    # predict xgb
    for it, (X, ind) in enumerate(get_pred_iterator_reg(config["aml_reg_dataset"], config["fileb"],  config["aml_reg_pipe"], config["test_batch_size"])):
        print('REG BATCH {}/{} '.format(it + 1, batch_cnt) + '=' * 90)
        preds = np.zeros(ind.shape[0])
        for m in config["aml_reg_models"]:
            preds += m.predict(X)

        preds /= len(config["aml_reg_models"])
        result["reg"] += list(preds)

    config.write_to_logfile('Построение предсказания линейной модели')

    # weighted sum
    result["prediction"] = config["w"] * np.array(result["reg"]) + (1 - config["w"]) * np.array(result["gbm"])
    config.write_to_logfile('Объединение предсказаний в композицию')


    y = result.pop("target")
    if len(y) > 0:
        res_df = pd.DataFrame({'line_id': np.array(result["line_id"]), 'TRUE': y, 'REG': np.array(result["reg"]), 'GBM': np.array(result["gbm"]), 'ENS': result["prediction"]})
    else:
        res_df = pd.DataFrame({'line_id': np.array(result["line_id"]), 'REG': np.array(result["reg"]), 'GBM': np.array(result["gbm"]), 'ENS': result["prediction"]})

    return res_df


def predict_new_process(config, test_file, offset, chunksize, verbose):
    
    print('CREATE ЕПТА')
    config["fileb"].create(test_file)
    print('DONE ЕПТА')
    config.write_to_logfile('Обработка тестового файла')
    
    res_df = predict_on_filebuilder(config, offset = offset, chunksize = chunksize, verbose = True, )
    
    return res_df

def get_file_offsets(file, n_jobs = 10):
    
    lens = []
    with open(file, 'rb') as f:
        # skip header
        header_len = len(f.readline())
        # get row lens
        l = 0
        for row in f:
            lens.append(l)
            l += len(row)
            
    lens = np.array(lens, dtype = np.int64)
    indexes = np.array_split(lens + header_len, n_jobs)
    offsets = [x[0]  for x in indexes]
    cnts = [x.shape[0]  for x in indexes]
    return offsets, cnts
