import os
import sys

sys.path.append('..')

import pandas as pd
from pandas import Series, DataFrame
import numpy as np
from .util import timeit, Config
from .preprocess import preprocess
from .model import train, predict
from typing import Callable, Union

from ..sbautoml.reader import get_train_df_w_reg
from ..sbautoml.optimizer import ObjGenerator
from ..sbautoml.filebuilder import FileBuilder

from .inference_tools import predict_on_filebuilder, get_file_offsets, predict_new_process

from sklearn.metrics import mean_squared_error, roc_auc_score
from sklearn import metrics
from ..sbautoml.pipelines.basic import FeatureSelectorDF

import joblib
from joblib import Parallel, delayed

import gc

import xgboost as xgb
import shap

import time


def fi_inverse_names(fi, fb):
    # automl feat names
    new_index = list(map(lambda x: x.split('__')[-1], fi.index))
    # inverse
    d = {}
    for i in fb.names:
        d[fb.names[i]] = i
    # set new index
    return Series(fi.values, index=[d[x] for x in new_index])


def get_feats_from_pipelines(*pipes):
    feats = []

    for pipe in pipes:
        for trnf in pipe.named_steps['features'].transformer_list:
            trnf = trnf[1]

            for sel in trnf.named_steps:
                if isinstance(trnf.named_steps[sel], FeatureSelectorDF):
                    feats += trnf.named_steps[sel].keys
                    break

    feats = sorted(list(set(feats)))
    return feats


def get_feat_dict(x):
    feat_dict = {'fw': {}, 'bw': {}}

    for i in x.columns:
        if 'id_' in i or 'datetime_' in i or 'string_' in i:
            feat_dict['fw'][i] = {'__SberBankAutoMLNaNValuE__': -1}
            feat_dict['bw'][i] = {-1: np.nan}
            for n, k in enumerate(x[i].dropna().drop_duplicates().values):
                feat_dict['fw'][i][k] = n
                feat_dict['bw'][i][n] = k
    return feat_dict


def update_feat_dict(x, feat_dict):
    for i in x.columns:
        if 'id' in i or 'datetime' in i or 'string' in i:

            for n, k in enumerate(x[i].dropna().drop_duplicates().values):
                if k not in feat_dict['fw'][i]:
                    feat_dict['fw'][i][k] = n
                    feat_dict['bw'][i][n] = k
    return None


def apply_dict(x, d, fw=True):
    fill = '__SberBankAutoMLNaNValuE__'  # if fw else -1

    x_ = x.copy()

    for i in d:
        if fw:
            x_[i] = x_[i].fillna(fill).map(d[i]).values
        else:
            x_[i] = x_[i].map(d[i]).values
    return x_


class AutoML:

    def __init__(self, vCPULimit=4, memoryLimit=12, timeLimit=300, encoding='utf-8', separator=',',
                 decimal=b'.', datetime_format=None, na_values=None, analyze_rows=100, embeddings_path=None,
                 use_gpu=True, test_batch_size=10000, cv_random_state=13, KFolds=10, log_file=None,featureSelParams = (None, 1, True),
                 metric: Union[str, Callable[[np.ndarray, np.ndarray], float]] = None):

        self.config = Config(vCPULimit=vCPULimit, memoryLimit=memoryLimit, timeLimit=timeLimit,
                             encoding=encoding, separator=separator, decimal=decimal, datetime_format=datetime_format,
                             na_values=na_values, analyze_rows=analyze_rows, embeddings_path=embeddings_path,
                             use_gpu=use_gpu, test_batch_size=test_batch_size, cv_random_state=cv_random_state,
                             KFolds=KFolds, log_file=log_file, featureSelParams = featureSelParams, metric=metric)
        # self.config['cache_dir'] = None

    def train(self, train_csv, featureRoles, mode, cache_dir=None, use_ids=False):
        self.config["task"] = "train"
        self.config["mode"] = mode
        self.config["cache_dir"] = cache_dir
        self.config["use_ids"] = use_ids
        self.config["start_time"] = time.time()

        if self.config["metric"][0] is None:
            if mode == "regression":
                self.config["metric"] = None, False
            else:
                self.config["metric"] = None, True

        # if cache_dir is not None:
        self.config["cache_dir"] = cache_dir
        if cache_dir is not None:
            os.makedirs(cache_dir, exist_ok=True)
            self.config.write_to_logfile('Создание необходимых директорий')

        self.config["fileb"] = FileBuilder(data_roles=featureRoles, analyze_rows=self.config["analyze_rows"],
                                           sep=self.config["separator"], encoding=self.config["encoding"],
                                           na_values=self.config["na_values"], decimal=self.config["decimal"],
                                           datetime_format=self.config["datetime_format"])

        self.config["fileb"].create_mapping(train_csv)
        self.config["fileb"].create(train_csv)
        self.config.write_to_logfile('Определение типов признаков')

        df, group, weight, dataset, pipe, cats, reg_pipe, reg_models, reg_oof_pred, reg_dataset, reg_sl = get_train_df_w_reg(
            self.config["fileb"], TASK="r" if mode == "regression" else "c",
            MEMORY_LIMIT=self.config["memory_limit"] // 3, VCPU_LIMIT=self.config["vCPU_limit"],
            use_ids=self.config["use_ids"], config=self.config)

        target = df['target'].values
        reg_oof_pred_ = np.zeros_like(target, dtype=np.float32)
        reg_oof_pred_[reg_sl] = reg_oof_pred
        del reg_oof_pred
        gc.collect()

        self.config["aml_dataset"] = dataset
        self.config["aml_pipe"] = pipe
        self.config["aml_cats"] = cats
        self.config["aml_feats"] = [x for x in df.columns if not x in ['line_id', 'target', 'group']]
        self.config["aml_reg_pipe"] = reg_pipe
        self.config["aml_reg_models"] = reg_models
        self.config["aml_reg_dataset"] = reg_dataset
        self.config["nrows"] = len(df)

        # connfig["aml_leak"]

        preprocess(df, self.config)
        self.config.write_to_logfile('Дополнительный препроцессинг данных')

        y = df["target"]
        X = df.drop("target", axis=1)

        gbm_oof_pred, succes = train(X, y, self.config, group=group, weight = weight)

        self.config.write_to_logfile('Построение LGBM модели')

        obj = ObjGenerator(reg_oof_pred_, gbm_oof_pred, target, dataset.task, succes * reg_sl, self.config["metric"])
        obj.optimize()

        self.config["w"] = np.clip(obj.w, 0, 1)
        obj.w = np.clip(obj.w, 0, 1)

        if (succes * reg_sl).sum() < 100:
            self.config["w"] = 1
            obj.w = 1

        print('WEIGHTS IN COMPOSITION: XGB  = {}, LGBM = {}'.format(self.config["w"], 1 - self.config["w"]))
        self.config.write_to_logfile(
            'WEIGHTS IN COMPOSITION: XGB  = {}, LGBM = {}'.format(self.config["w"], 1 - self.config["w"]))

        self.config.write_to_logfile('Оптимизация композиции алгоритмов')

        self.config["pfeats"] = get_feats_from_pipelines(self.config['aml_reg_pipe'], self.config['aml_pipe'])
        self._create_explainer(self.config["fileb"])

        self.config.write_to_logfile('Удаление временных файлов')
        self.config['isTrained'] = True
        # вернул drop_last
        self.config['fileb'].drop_last()

        return pd.DataFrame({'TRUE': obj.y, 'REG': obj.reg, 'GBM': obj.gbm,
                             'ENS': obj.reg * obj.w + obj.gbm * (1 - obj.w)}), fi_inverse_names(self.config['feat_imp'],
                                                                                                self.config.data[
                                                                                                    'fileb'])

    def predict(self, test_csv, prediction_csv=None, n_jobs=1, cache_dir=None):

        self.config["task"] = "predict"
        # if cache_dir is not None:
        self.config["cache_dir"] = cache_dir
        if cache_dir is not None:
            os.makedirs(cache_dir, exist_ok=True)
            self.config.write_to_logfile('Создание необходимых директорий')

        # check if we have texts in pipelines
        feats = get_feats_from_pipelines(self.config["aml_pipe"], self.config["aml_reg_pipe"])
        flg_text = len([x for x in feats if 'text_' in feats]) > 0

        if n_jobs == 1 or flg_text:
            if flg_text and n_jobs > 1:
                print('TEXT FEATS FOUND, N_JOBS SET TO 1')
            self.config["fileb"].create(test_csv)
            self.config.write_to_logfile('Обработка тестового файла')

            res_df = predict_on_filebuilder(self.config, offset=None, chunksize=None, verbose=True, )
            # вернул всратый drop_last(((
            self.config['fileb'].drop_last()
        else:
            # разные параметры для файла и датафрейма
            if type(test_csv) is str:
                offsets, cnts = get_file_offsets(test_csv, n_jobs=n_jobs)
                params = [(self.config, test_csv, x, y, False) for (x, y) in zip(offsets, cnts)]
            else:
                params = [(self.config, x, 0, None, False) for x in np.array_split(test_csv, n_jobs)]

            with Parallel(n_jobs=n_jobs, prefer='processes') as p:
                res_df = p(delayed(predict_new_process)(*x) for x in params)
            res_df = pd.concat(res_df, ignore_index=True)
            if self.config.data['fileb'].index_col is None:
                res_df['line_id'] = np.arange(len(res_df), dtype=np.int64)

        if 'TRUE' in res_df.columns:
            if self.config["metric"][0] is None:
                if self.config["mode"] == 'classification':
                    score = roc_auc_score(res_df['TRUE'].values, res_df['ENS'].values)
                else:
                    score = np.sqrt(mean_squared_error(res_df['TRUE'].values, res_df['ENS'].values))
            elif isinstance(self.config["metric"][0], str):
                score_func = getattr(metrics, self.config["metric"][0])
                score = score_func(res_df['TRUE'].values, res_df['ENS'].values)
            else:
                score = self.config["metric"][0](res_df['TRUE'].values, res_df['ENS'].values)

        else:
            score = None

        result = res_df[['line_id', 'ENS']]
        result.columns = ['line_id', 'prediction']
        if prediction_csv is not None:
            result.to_csv(prediction_csv, index=False)
            self.config.write_to_logfile('Сохранение финальных предсказаний в файл')

        self.config.write_to_logfile('Удаление временных файлов')

        return result, score, res_df

    def get_new_dataset(self, test_csv):

        self.config["fileb"].create(test_csv)
        df = self.config["aml_reg_dataset"].get_df(fb=self.config["fileb"], test=True)[self.config["pfeats"]]

        df.columns = self.config["fileb"].transform_names(self.config["pfeats"], fw=False)

        return df

    def _create_explainer(self, fb):

        df = self.config["aml_reg_dataset"].get_df(fb=self.config["fileb"], nrows=10000, test=True)[
            self.config["pfeats"]]
        df = df.sample(20)

        self.config.data['feat_dict'] = get_feat_dict(df)
        df = apply_dict(df, self.config.data['feat_dict']['fw'])

        self.config.data['explainer'] = shap.KernelExplainer(self._score_array, df, size=20)
        return self.config.data['explainer']

    def _score_array(self, x):

        print(x.shape[0])
        self.config["task"] = "predict"

        x = DataFrame(x, columns=self.config["pfeats"])
        x.index.name = 'line_id'

        x = apply_dict(x, self.config.data['feat_dict']['bw'], False)

        for i in x.columns:
            x[i] = x[i].astype(self.config['fileb'].dtypes[i])
            if 'datetime' in i:
                x[i] = pd.to_datetime(x[i], format=self.config.data['datetime_format'])

        dm = xgb.DMatrix(self.config['aml_reg_pipe'].transform(x))

        index = x.index.values
        ds = self.config['aml_pipe'].transform(x)

        ds = DataFrame(ds, columns=self.config['aml_pipe'].get_feature_names())
        ds['line_id'] = index

        preprocess(ds, self.config)

        reg_preds = np.zeros(x.shape[0])
        gbm_preds = list(predict(ds, self.config))

        for m in self.config["aml_reg_models"]:
            reg_preds += m.predict(dm)

        reg_preds /= len(self.config["aml_reg_models"])

        res = self.config["w"] * np.array(reg_preds) + (1 - self.config["w"]) * np.array(gbm_preds)
        return res

    def explain(self, row):
        # shap.initjs()
        # mapping = fi_inverse_names(self.config['feat_imp'], self.config.data['fileb'])
        row.columns = self.config["fileb"].transform_names(row.columns, fw=True)
        update_feat_dict(row, self.config.data['feat_dict'])
        row = apply_dict(row, self.config.data['feat_dict']['fw'])

        d = {}
        for i in self.config.data['fileb'].names:
            d[self.config.data['fileb'].names[i]] = i

        test_shap_vals = self.config.data['explainer'].shap_values(row)
        return shap.force_plot(self.config.data['explainer'].expected_value, test_shap_vals, row,
                               feature_names=self.config["fileb"].transform_names(self.config["pfeats"], fw=False))

    @timeit
    def save(self, fname):
        joblib.dump(self.config, fname)

    @timeit
    def load(self, fname):
        if not self.config['isTrained']:
            self.config = joblib.load(fname)
            self.config['isTrained'] = True

    def __getstate__(self):
        state = self.config
        return state

    def __setstate__(self, state):
        self.config = state

    def set_params(self, **kwargs):
        for k in kwargs.keys():
            self.config.data[k] = kwargs[k]
