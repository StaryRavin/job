from sber_ailab_automl import AutoML
import sys
import argparse
import json

def train():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['classification', 'regression'], required = True)
    parser.add_argument('--model-dir', required = True)
    parser.add_argument('--train-csv', required = True)
    parser.add_argument('--vCPULimit', default = 20)
    parser.add_argument('--memoryLimit', default = 12 * 1024)
    parser.add_argument('--timeLimit', default = 1800)
    parser.add_argument('--encoding', default = 'utf-8')
    parser.add_argument('--separator', default = ',')
    parser.add_argument('--decimal', default = '.')
    parser.add_argument('--feature-roles', required = True)
    parser.add_argument('--na-values', default = None)
    parser.add_argument('--rows-to-analyze', default = 1000)
    parser.add_argument('--datetime-format', default = '%Y-%m-%d')
    args = parser.parse_args()
    
    automl = AutoML(model_dir = args.model_dir, 
                        vCPULimit = int(args.vCPULimit), 
                        memoryLimit = int(args.memoryLimit), 
                        timeLimit = int(args.timeLimit), 
                        encoding = args.encoding, 
                        separator = args.separator, 
                        decimal = args.decimal, 
                        datetime_format = args.datetime_format, 
                        na_values = args.na_values, 
                        analyze_rows = int(args.rows_to_analyze))

    automl.train(args.train_csv, json.loads(args.feature_roles), args.mode, use_ids = False)
    automl.save()
    
def predict():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model-dir', required = True)
    parser.add_argument('--test-csv', required = True)
    parser.add_argument('--prediction-csv', required = True)
    parser.add_argument('--vCPULimit', default = 20)
    parser.add_argument('--memoryLimit', default = 12 * 1024)
    parser.add_argument('--timeLimit', default = 1800)
    parser.add_argument('--encoding', default = 'utf-8')
    parser.add_argument('--separator', default = ',')
    parser.add_argument('--decimal', default = '.')
    parser.add_argument('--feature-roles', default = {})
    parser.add_argument('--na-values', default = None)
    parser.add_argument('--rows-to-analyze', default = 1000)
    parser.add_argument('--datetime-format', default = '%Y-%m-%d')
    args = parser.parse_args()
    
    automl = AutoML(model_dir = args.model_dir, 
                        vCPULimit = int(args.vCPULimit), 
                        memoryLimit = int(args.memoryLimit), 
                        timeLimit = int(args.timeLimit), 
                        encoding = args.encoding, 
                        separator = args.separator, 
                        decimal = args.decimal, 
                        datetime_format = args.datetime_format, 
                        na_values = args.na_values, 
                        analyze_rows = int(args.rows_to_analyze))

    automl.load()
    _, score = automl.predict(args.test_csv, args.prediction_csv)
    if score is not None:
        print('Model score is {}'.format(score))
    else:
        print('Test dataset does not have target variable. Please calculate test score manually.')
        
    