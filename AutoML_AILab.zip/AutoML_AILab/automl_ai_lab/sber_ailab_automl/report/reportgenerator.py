import pandas as pd
import numpy as np
import os
from jinja2 import FileSystemLoader, Environment
from datetime import datetime
from sklearn.metrics import roc_auc_score, precision_recall_fscore_support, roc_curve, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from ..lib.util import GroupKFoldSeed
from sklearn.model_selection import StratifiedKFold
from ..lib.automl import AutoML
import time
from shutil import copyfile
import ast
import random as rndm
from collections import Counter, defaultdict

def stratified_group_k_fold(X, y, groups, k, seed=None):
    y = y.astype(int)
    labels_num = np.max(y) + 1
    y_counts_per_group = defaultdict(lambda: np.zeros(labels_num))
    y_distr = Counter()
    for label, g in zip(y, groups):
        y_counts_per_group[g][label] += 1
        y_distr[label] += 1

    y_counts_per_fold = defaultdict(lambda: np.zeros(labels_num))
    groups_per_fold = defaultdict(set)

    def eval_y_counts_per_fold(y_counts, fold):
        y_counts_per_fold[fold] += y_counts
        std_per_label = []
        for label in range(labels_num):
            label_std = np.std([y_counts_per_fold[i][label] / y_distr[label] for i in range(k)])
            std_per_label.append(label_std)
        y_counts_per_fold[fold] -= y_counts
        return np.mean(std_per_label)
    
    groups_and_y_counts = list(y_counts_per_group.items())
    rndm.Random(seed).shuffle(groups_and_y_counts)

    for g, y_counts in sorted(groups_and_y_counts, key=lambda x: -np.std(x[1])):
        best_fold = None
        min_eval = None
        for i in range(k):
            fold_eval = eval_y_counts_per_fold(y_counts, i)
            if min_eval is None or fold_eval < min_eval:
                min_eval = fold_eval
                best_fold = i
        y_counts_per_fold[best_fold] += y_counts
        groups_per_fold[best_fold].add(g)

    all_groups = set(groups)
    for i in range(k):
        train_groups = all_groups - groups_per_fold[i]
        test_groups = groups_per_fold[i]

        train_indices = [i for i, g in enumerate(groups) if g in train_groups]
        test_indices = [i for i, g in enumerate(groups) if g in test_groups]

        yield train_indices, test_indices

def plot_roc_curve_image(data, path):
    sns.set(style="whitegrid", font_scale=1.5)
    plt.figure(figsize=(10, 10));

    fpr_reg, tpr_reg, _ = roc_curve(data['TRUE'].values, data['REG'].values)
    auc_score_reg = roc_auc_score(y_true=data['TRUE'].values, y_score=data['REG'].values)

    fpr_gbm, tpr_gbm, _ = roc_curve(data['TRUE'].values, data['GBM'].values)
    auc_score_gbm = roc_auc_score(y_true=data['TRUE'].values, y_score=data['GBM'].values)

    fpr_ens, tpr_ens, _ = roc_curve(data['TRUE'].values, data['ENS'].values)
    auc_score_ens = roc_auc_score(y_true=data['TRUE'].values, y_score=data['ENS'].values)

    lw = 2
    plt.plot(fpr_reg, tpr_reg, color='darkorange',
             lw=lw, label='Линейная модель (GINI = {:.3f})'.format(2 * auc_score_reg - 1));
    plt.plot(fpr_gbm, tpr_gbm, color='blue',
             lw=lw, label='LGBM модель (GINI = {:.3f})'.format(2 * auc_score_gbm - 1));
    plt.plot(fpr_ens, tpr_ens, color='green',
             lw=lw, label='Финальная модель (GINI = {:.3f})'.format(2 * auc_score_ens - 1));
    plt.plot([0, 1], [0, 1], color='red', lw=lw, linestyle='--', label = 'Случайная модель');
    plt.xlim([-0.05, 1.05]);
    plt.ylim([-0.05, 1.05]);
    plt.xlabel('False Positive Rate');
    plt.ylabel('True Positive Rate');
    lgd = plt.legend(bbox_to_anchor=(0.5, -0.15), loc='upper center', ncol = 2);
    plt.xticks(np.arange(0, 1.01, 0.05), rotation = 45);
    plt.yticks(np.arange(0, 1.01, 0.05));
    plt.grid(color='gray', linestyle='-', linewidth=1);
    plt.title('ROC кривая (Финальный GINI = {:.3f})'.format(2 * auc_score_ens - 1));
    plt.savefig(path, bbox_extra_artists=(lgd,), bbox_inches='tight');
    plt.close()
    
def plot_pie_f1_metric(data, path, F1_thresh):
    tn, fp, fn, tp = confusion_matrix(data['TRUE'].values, (data['ENS'].values > F1_thresh).astype(int)).ravel()
    (_, prec), (_, rec), (_, F1), (_, _) = precision_recall_fscore_support(data['TRUE'].values, 
                                                                           (data['ENS'].values > F1_thresh).astype(int))

    sns.set(style="whitegrid", font_scale=1.5)
    fig, ax = plt.subplots(figsize=(20, 10), subplot_kw=dict(aspect="equal"))

    recipe = ["{} True Positives".format(tp),
              "{} False Positives".format(fp),
              "{} False Negatives".format(fn),
              "{} True Negatives".format(tn)]

    data = [tp, fp, fn, tn]

    wedges, texts = ax.pie(data, wedgeprops=dict(width=0.5), startangle=-40)

    bbox_props = dict(boxstyle="square,pad=0.3", fc="w", ec="k", lw=0.72)
    kw = dict(arrowprops=dict(arrowstyle="-", color = 'k'),
              bbox=bbox_props, zorder=0, va="center")

    for i, p in enumerate(wedges):
        ang = (p.theta2 - p.theta1)/2. + p.theta1
        y = np.sin(np.deg2rad(ang))
        x = np.cos(np.deg2rad(ang))
        horizontalalignment = {-1: "right", 1: "left"}[int(np.sign(x))]
        connectionstyle = "angle,angleA=0,angleB={}".format(ang)
        kw["arrowprops"].update({"connectionstyle": connectionstyle})
        ax.annotate(recipe[i], xy=(x, y), xytext=(1.35*np.sign(x), 1.4*y),
                    horizontalalignment=horizontalalignment, **kw)

    ax.set_title("Финальная модель: Точность = {:.2f}%, Полнота = {:.2f}%, F1-Score = {:.2f}%".format(prec * 100, rec * 100, F1 * 100))
    plt.savefig(path, bbox_inches='tight');
    plt.close()
    
def plot_bins_preds(data, path):
    sns.set(style="whitegrid", font_scale=1.5)
    fig, axs = plt.subplots(2,1,figsize=(16,20))

    box_plot_data = []
    labels = []
    for name, group in data.groupby('bin'):
        labels.append(name)
        box_plot_data.append(group.ENS.values)

    box = axs[0].boxplot(box_plot_data,patch_artist=True,labels=labels)
    for patch in box['boxes']:
        patch.set_facecolor('green')
    axs[0].set_yscale('log')
    axs[0].set_xlabel('Номер бина')
    axs[0].set_ylabel('Предсказание')
    axs[0].set_title('Распределение предсказаний объектов по бинам')

    data['ENS_logit'] = np.log(data['ENS'].values / (1 - data['ENS'].values))
    sns.kdeplot(data[data['TRUE'] == 0]['ENS_logit'], shade=True, color="r", label = 'Class 0 logits', ax = axs[1])
    sns.kdeplot(data[data['TRUE'] == 1]['ENS_logit'], shade=True, color="g", label = 'Class 1 logits', ax = axs[1])
    axs[1].set_xlabel('Logits')
    axs[1].set_ylabel('Плотность')
    axs[1].set_ylim([-0.05, 1.05])
    axs[1].set_yticks(np.arange(0, 1.01, 0.05));
    axs[1].set_title('Распределение Logit-ов предсказаний объектов (в разбивке по классам)');
    fig.savefig(path, bbox_inches='tight');
    plt.close()


def f1_score_w_co(y_true, y_pred, min_co = .01, max_co = .99, step = 0.01):
    
    y_pred = np.clip(np.ceil(y_pred / step) * step, min_co, max_co)
    
    pos = y_true.sum()
    neg = y_true.shape[0] - pos

    grp = pd.DataFrame({'true': y_true, 'pred': y_pred}).groupby('pred')['true'].agg(['sum', 'count'])
    grp.sort_index(inplace = True)
    
    grp['fp'] = grp['sum'].cumsum()
    grp['tp'] = pos - grp['fp'] 
    grp['tn'] = (grp['count'] - grp['sum']).cumsum()
    grp['fn'] = neg - grp['tn']
    
    grp['pr']  = grp['tp'] / (grp['tp'] + grp['fp'])
    grp['rec'] = grp['tp'] / (grp['tp'] + grp['fn'])
    
    grp['f1_score'] = 2 * (grp['pr'] * grp['rec']) / (grp['pr'] + grp['rec'])
    
    best_score = grp['f1_score'].max()
    best_co = grp.index.values[grp['f1_score'] == best_score].mean()
    
    #print((y_pred < best_co).mean())
    
    return best_score, best_co

class ReportGenerator():
    def __init__(self):
        self.env = Environment(loader=FileSystemLoader(searchpath=os.path.dirname(__file__)))
        self.base_template = self.env.get_template('report_template.html')
        
    def train_OOS_automl(self, report_params):
        # TRAIN AUTOML ON FULL TRAIN DATA
        start_time = time.time()
        automl = AutoML(vCPULimit = report_params['automl_params']['vCPULimit'], 
                    memoryLimit = report_params['automl_params']['memoryLimit'], 
                    timeLimit = report_params['automl_params']['timeLimit'], 
                    encoding = report_params['automl_params']['encoding'], 
                    separator = report_params['automl_params']['separator'], 
                    decimal = report_params['automl_params']['decimal'], 
                    datetime_format = report_params['automl_params']['datetimeFormat'], 
                    na_values = report_params['automl_params']['naValues'], 
                    analyze_rows = report_params['automl_params']['rowsToAnalyze'],
                    test_batch_size = report_params['automl_params']['testBatchSize'],
                    cv_random_state = report_params['automl_params']['LuckySeed'],
                    KFolds = report_params['automl_params']['KFolds'],
                    featureSelParams = report_params['automl_params']['featureSelParams'],
                   log_file = os.path.join(report_params['output_path'], 'AUTOML_TRAIN_LOG_FULL.txt'))

        report_params['automl_res_df'], report_params['automl_feat_imp'] = automl.train(report_params['automl_params']['trainDatasetFName'], 
                                                                                        report_params['automl_params']['featureRoles'],
                                                                                        report_params['automl_params']['type'])
        automl.save(os.path.join(report_params['output_path'], 'MODEL_ON_FULL_TRAIN.pkl'))
        self.full_train_automl_time = time.time() - start_time
        start_time = time.time()
        _, score, report_params['automl_res_df_test'] = automl.predict(report_params['automl_params']['testDatasetFName'], 
                                                                       report_params['automl_params']['predictionsFName'])
        self.full_train_automl_prediction_time = time.time() - start_time
        print('FULL_SCORE_OOT = {}'.format(score))
        
        # TRAIN TRUE OOS + OOT AUTOML
        data = pd.read_csv(report_params['automl_params']['trainDatasetFName'])
        print('DATA_SHAPE = {}'.format(data.shape))
        if 'group' in report_params['automl_params']['featureRoles']:
            print('USE GroupKFold')
            group = data[report_params['automl_params']['featureRoles']['group']].values
            # stratified_group_k_fold(X, y, groups, k, seed=None)
            gkf = stratified_group_k_fold(data[report_params['automl_params']['featureRoles']['target']].values, data[report_params['automl_params']['featureRoles']['target']].values, group, k = 5, seed= 13)
            for train_index, test_index in gkf:
                break
        else:
            print('USE StratifiedKFold')
            strat = data[report_params['automl_params']['featureRoles']['target']].values
            skf = StratifiedKFold(n_splits = 5, shuffle = True, random_state = 13)
            for train_index, test_index in skf.split(strat,strat):
                break

        X_train = data.iloc[train_index, :]
        X_valid = data.iloc[test_index, :]
        print('X_TRAIN SHAPE = {}, X_VALID SHAPE = {}'.format(X_train.shape, X_valid.shape))
        
        X_train.to_csv(os.path.join(report_params['output_path'], 'X_train.csv'), index = False)
        X_valid.to_csv(os.path.join(report_params['output_path'], 'X_valid_OOS.csv'), index = False)
        
        start_time = time.time()
        self.automl = AutoML(vCPULimit = report_params['automl_params']['vCPULimit'], 
                    memoryLimit = report_params['automl_params']['memoryLimit'], 
                    timeLimit = report_params['automl_params']['timeLimit'], 
                    encoding = report_params['automl_params']['encoding'], 
                    separator = report_params['automl_params']['separator'], 
                    decimal = report_params['automl_params']['decimal'], 
                    datetime_format = report_params['automl_params']['datetimeFormat'], 
                    na_values = report_params['automl_params']['naValues'], 
                    analyze_rows = report_params['automl_params']['rowsToAnalyze'],
                    test_batch_size = report_params['automl_params']['testBatchSize'],
                    cv_random_state = report_params['automl_params']['LuckySeed'],
                    KFolds = report_params['automl_params']['KFolds'],
                    featureSelParams = report_params['automl_params']['featureSelParams'],
                    log_file = os.path.join(report_params['output_path'], 'AUTOML_TRAIN_LOG_TRUE_OOS_OOT.txt'))

        self.OOF_res_df, self.OOF_feat_imp = self.automl.train(os.path.join(report_params['output_path'], 'X_train.csv'), report_params['automl_params']['featureRoles'], report_params['automl_params']['type'], )
        self.automl.save(os.path.join(report_params['output_path'], 'MODEL_FOR_OOS.pkl'))
        self.OOS_train_automl_time = time.time() - start_time
        start_time = time.time()
        _, score, self.OOS_res_df_test = self.automl.predict(os.path.join(report_params['output_path'], 'X_valid_OOS.csv'), report_params['automl_params']['predictionsFName'])
        self.OOS_train_automl_prediction_OOS_time = time.time() - start_time
        print('TRUE_SCORE_OOS = {}'.format(score))
        start_time = time.time()
        _, score, self.OOT_res_df_test = self.automl.predict(report_params['automl_params']['testDatasetFName'], report_params['automl_params']['predictionsFName'])
        self.OOS_train_automl_prediction_OOT_time = time.time() - start_time
        print('TRUE_SCORE_OOT = {}'.format(score))
        
        # FILL SOME PARAMS FOR REPORT
        if report_params['automl_date_column'] is not None:
            dt = pd.to_datetime(X_train[report_params['automl_date_column']], format = report_params['automl_params']['datetimeFormat'])
            tr_dt_min, tr_dt_max = dt.min(), dt.max()
            dt = pd.to_datetime(X_valid[report_params['automl_date_column']], format = report_params['automl_params']['datetimeFormat'])
            val_dt_min, val_dt_max = dt.min(), dt.max()
            
            self.train_period_80 = tr_dt_min.strftime('%d.%m.%Y') + ' - ' + tr_dt_max.strftime('%d.%m.%Y')
            self.valid_period = val_dt_min.strftime('%d.%m.%Y') + ' - ' + val_dt_max.strftime('%d.%m.%Y')
        else:
            self.train_period_80 = '---'
            self.valid_period = '---'
        
    def calculate_values(self, report_params):

        report_params['automl_res_df'].sort_values('ENS', ascending = False, inplace = True)
        report_params['automl_res_df_test'].sort_values('ENS', ascending = False, inplace = True)
        self.OOF_res_df.sort_values('ENS', ascending = False, inplace = True)
        self.OOS_res_df_test.sort_values('ENS', ascending = False, inplace = True)
        self.OOT_res_df_test.sort_values('ENS', ascending = False, inplace = True)
        
        if report_params['automl_date_column'] is not None:
            train_dt = pd.read_csv(report_params['automl_params']['trainDatasetFName'], usecols = [report_params['automl_date_column']])[report_params['automl_date_column']]
            train_dt = pd.to_datetime(train_dt, format = report_params['automl_params']['datetimeFormat'])
            tr_dt_min, tr_dt_max = train_dt.min(), train_dt.max()
            test_dt = pd.read_csv(report_params['automl_params']['testDatasetFName'], usecols = [report_params['automl_date_column']])[report_params['automl_date_column']]
            test_dt = pd.to_datetime(test_dt, format = report_params['automl_params']['datetimeFormat'])
            te_dt_min, te_dt_max = test_dt.min(), test_dt.max()
            full_dt = pd.concat([train_dt, test_dt])
            full_dt_min, full_dt_max = full_dt.min(), full_dt.max()
            
            self.train_period = tr_dt_min.strftime('%d.%m.%Y') + ' - ' + tr_dt_max.strftime('%d.%m.%Y')
            self.test_period = te_dt_min.strftime('%d.%m.%Y') + ' - ' + te_dt_max.strftime('%d.%m.%Y')
            self.full_period = full_dt_min.strftime('%d.%m.%Y') + ' - ' + full_dt_max.strftime('%d.%m.%Y')
        else:
            self.train_period = '---'
            self.test_period = '---'
            self.full_period = '---'
        
        # Counts
        self.count_train = report_params['automl_res_df'].shape[0]
        self.count_test = report_params['automl_res_df_test'].shape[0]
        self.count_full = self.count_train + self.count_test
        self.count_train_80 = self.OOF_res_df.shape[0]
        self.count_valid = self.OOS_res_df_test.shape[0]
        
        # Part percent
        self.train_part_perc = self.count_train / self.count_full * 100
        self.test_part_perc = self.count_test / self.count_full * 100
        self.train_part_perc_80 = self.count_train_80 / self.count_train * 100
        self.valid_part_perc = self.count_valid / self.count_train * 100
        
        # Target counts
        self.train_target_cnt = report_params['automl_res_df']['TRUE'].sum()
        self.test_target_cnt = report_params['automl_res_df_test']['TRUE'].sum()
        self.full_target_cnt = self.train_target_cnt + self.test_target_cnt
        self.train_target_cnt_80 = self.OOF_res_df['TRUE'].sum()
        self.valid_target_cnt = self.OOS_res_df_test['TRUE'].sum()
        
        # Non-Target counts
        self.train_nontarget_cnt = self.count_train - self.train_target_cnt
        self.test_nontarget_cnt = self.count_test - self.test_target_cnt
        self.full_nontarget_cnt = self.count_full - self.full_target_cnt
        self.train_nontarget_cnt_80 = self.count_train_80 - self.train_target_cnt_80
        self.valid_nontarget_cnt = self.count_valid - self.valid_target_cnt
        
        # Target percent
        self.train_target_perc = report_params['automl_res_df']['TRUE'].mean() * 100
        self.test_target_perc = report_params['automl_res_df_test']['TRUE'].mean() * 100
        full_target_list = list(report_params['automl_res_df']['TRUE'].values) + list(report_params['automl_res_df_test']['TRUE'].values)
        self.full_target_perc = np.mean(full_target_list) * 100
        self.train_target_perc_80 = self.OOF_res_df['TRUE'].mean() * 100
        self.valid_target_perc = self.OOS_res_df_test['TRUE'].mean() * 100
        
        # AUCs
        self.train_AUC_full = 100 * roc_auc_score(report_params['automl_res_df']['TRUE'].values, report_params['automl_res_df']['ENS'].values)
        self.test_AUC_full = 100 * roc_auc_score(report_params['automl_res_df_test']['TRUE'].values, report_params['automl_res_df_test']['ENS'].values)
        self.train_AUC_80 = 100 * roc_auc_score(self.OOF_res_df['TRUE'].values, self.OOF_res_df['ENS'].values)
        self.valid_AUC = 100 * roc_auc_score(self.OOS_res_df_test['TRUE'].values, self.OOS_res_df_test['ENS'].values)
        self.test_AUC = 100 * roc_auc_score(self.OOT_res_df_test['TRUE'].values, self.OOT_res_df_test['ENS'].values)
        
        # Gini-s
        self.train_GINI_full = 2 * self.train_AUC_full - 100
        self.test_GINI_full = 2 * self.test_AUC_full - 100
        self.train_GINI_80 = 2 * self.train_AUC_80 - 100
        self.valid_GINI = 2 * self.valid_AUC - 100
        self.test_GINI = 2 * self.test_AUC - 100
        
        # Precision, Recall, F1
        _, self.F1_thresh_full = f1_score_w_co(report_params['automl_res_df']['TRUE'].values, report_params['automl_res_df']['ENS'].values)
        (_, self.train_precision_full), (_, self.train_recall_full), (_, self.train_F1_full), (_, _) = precision_recall_fscore_support(
                                                report_params['automl_res_df']['TRUE'].values, 
                                                (report_params['automl_res_df']['ENS'].values > self.F1_thresh_full).astype(int))
        (_, self.test_precision_full), (_, self.test_recall_full), (_, self.test_F1_full), (_, _) = precision_recall_fscore_support(
                                                report_params['automl_res_df_test']['TRUE'].values, 
                                                (report_params['automl_res_df_test']['ENS'].values > self.F1_thresh_full).astype(int))
        
        _, self.F1_thresh = f1_score_w_co(self.OOF_res_df['TRUE'].values, self.OOF_res_df['ENS'].values)
        (_, self.train_precision_80), (_, self.train_recall_80), (_, self.train_F1_80), (_, _) = precision_recall_fscore_support(
                                                self.OOF_res_df['TRUE'].values, 
                                                (self.OOF_res_df['ENS'].values > self.F1_thresh).astype(int))
        (_, self.valid_precision), (_, self.valid_recall), (_, self.valid_F1), (_, _) = precision_recall_fscore_support(
                                                self.OOS_res_df_test['TRUE'].values, 
                                                (self.OOS_res_df_test['ENS'].values > self.F1_thresh).astype(int))
        (_, self.test_precision), (_, self.test_recall), (_, self.test_F1), (_, _) = precision_recall_fscore_support(
                                                self.OOT_res_df_test['TRUE'].values, 
                                                (self.OOT_res_df_test['ENS'].values > self.F1_thresh).astype(int))
        
        
        report_params['automl_res_df']['bin'] = (np.array(list(range(len(report_params['automl_res_df'])))) / len(report_params['automl_res_df']) * 20).astype(int)
        self.train_bins_full = report_params['automl_res_df'].groupby('bin').agg({'TRUE': [len, np.mean], 'ENS': [np.min, np.mean, np.max]}).values
        
        report_params['automl_res_df_test']['bin'] = (np.array(list(range(len(report_params['automl_res_df_test'])))) / len(report_params['automl_res_df_test']) * 20).astype(int)
        self.test_bins_full = report_params['automl_res_df_test'].groupby('bin').agg({'TRUE': [len, np.mean], 'ENS': [np.min, np.mean, np.max]}).values
        
        self.OOF_res_df['bin'] = (np.array(list(range(len(self.OOF_res_df)))) / len(self.OOF_res_df) * 20).astype(int)
        self.train_bins = self.OOF_res_df.groupby('bin').agg({'TRUE': [len, np.mean], 'ENS': [np.min, np.mean, np.max]}).values
        
        self.OOS_res_df_test['bin'] = (np.array(list(range(len(self.OOS_res_df_test)))) / len(self.OOS_res_df_test) * 20).astype(int)
        self.valid_bins = self.OOS_res_df_test.groupby('bin').agg({'TRUE': [len, np.mean], 'ENS': [np.min, np.mean, np.max]}).values
        
        self.OOT_res_df_test['bin'] = (np.array(list(range(len(self.OOT_res_df_test)))) / len(self.OOT_res_df_test) * 20).astype(int)
        self.test_bins = self.OOT_res_df_test.groupby('bin').agg({'TRUE': [len, np.mean], 'ENS': [np.min, np.mean, np.max]}).values
        
    def plot_graphs(self, report_params):
        plot_roc_curve_image(report_params['automl_res_df'], os.path.join(report_params['output_path'], 'AUC_train_plot_full.png'))
        plot_pie_f1_metric(report_params['automl_res_df'], os.path.join(report_params['output_path'], 'F1_train_plot_full.png'), self.F1_thresh_full)
        plot_bins_preds(report_params['automl_res_df'], os.path.join(report_params['output_path'], 'bins_train_plot_full.png'))
        
        plot_roc_curve_image(report_params['automl_res_df_test'], os.path.join(report_params['output_path'], 'AUC_test_plot_full.png'))
        plot_pie_f1_metric(report_params['automl_res_df_test'], os.path.join(report_params['output_path'], 'F1_test_plot_full.png'), self.F1_thresh_full)
        plot_bins_preds(report_params['automl_res_df_test'], os.path.join(report_params['output_path'], 'bins_test_plot_full.png'))
        
        plot_roc_curve_image(self.OOF_res_df, os.path.join(report_params['output_path'], 'AUC_train_plot.png'))
        plot_pie_f1_metric(self.OOF_res_df, os.path.join(report_params['output_path'], 'F1_train_plot.png'), self.F1_thresh)
        plot_bins_preds(self.OOF_res_df, os.path.join(report_params['output_path'], 'bins_train_plot.png'))
        
        plot_roc_curve_image(self.OOS_res_df_test, os.path.join(report_params['output_path'], 'AUC_valid_plot.png'))
        plot_pie_f1_metric(self.OOS_res_df_test, os.path.join(report_params['output_path'], 'F1_valid_plot.png'), self.F1_thresh)
        plot_bins_preds(self.OOS_res_df_test, os.path.join(report_params['output_path'], 'bins_valid_plot.png'))
        
        plot_roc_curve_image(self.OOT_res_df_test, os.path.join(report_params['output_path'], 'AUC_test_plot.png'))
        plot_pie_f1_metric(self.OOT_res_df_test, os.path.join(report_params['output_path'], 'F1_test_plot.png'), self.F1_thresh)
        plot_bins_preds(self.OOT_res_df_test, os.path.join(report_params['output_path'], 'bins_test_plot.png'))
    
    def generate_interpret_imgs(self, report_params):
        tmp = self.automl.get_new_dataset(report_params['automl_params']['testDatasetFName'])
        idx_to_choose = [np.linspace(0, len(tmp) - 1, 5).astype(int)]
        preds = self.OOT_res_df_test['ENS'].values[idx_to_choose]
        true_labels = self.OOT_res_df_test['TRUE'].values[idx_to_choose]
        idxs = self.OOT_res_df_test['line_id'].values[idx_to_choose]
        self.interpret_imgs = []
        for idx, pred, label in zip(idxs, preds, true_labels):
            obj = tmp.loc[[idx]]
            for col in obj.columns:
                if obj[col].values[0] is None:
                    if 'datetime' in col:
                        obj[col] = np.datetime64('NaT')
                    else:
                        obj[col] = np.nan
            text_with_js = self.automl.explain(obj).data
            dict_for_js = ast.literal_eval(text_with_js[text_with_js.find('"outNames"') - 1:-70].replace(' NaN', ' "NaN"').replace(' NaT', ' "NaT"').replace(' Infinity', ' "Infinity"').replace(' null', ' "null"'))
            mapper = obj.reset_index(drop=True).iloc[0].to_dict()
            for it, feat_name in enumerate(dict_for_js['featureNames']):
                if str(it) in dict_for_js['features']:
                    try:
                        dict_for_js['features'][str(it)]['value'] = transliterate.translit(str(mapper[self.automl.config['fileb'].names[feat_name]]), reversed = True).replace("'", "")
                    except:
                        dict_for_js['features'][str(it)]['value'] = mapper[self.automl.config['fileb'].names[feat_name]]
            text_with_js = text_with_js[:text_with_js.find('"outNames"') - 1] + str(dict_for_js).replace("'", '"') + text_with_js[-70:]
            text_with_js = text_with_js.replace(' nan', ' "<?>"').replace(' inf', ' "<?>"').replace(' Timestamp(', ' ').replace('")}', '"}').replace(' NaT', ' "NaT"').replace(' "null"', ' null')
            self.interpret_imgs.append((round(pred, 3), int(label), text_with_js))
        
    def write_report_to_file(self, report_params):
        
        with open(os.path.join(report_params['output_path'], 'report.html'), "w") as f:
            f.write(self.base_template.render(
                report_name = str(report_params['report_name']),
                report_version = str(report_params['report_version_id']),
                city = str(report_params['city']),
                year = str(datetime.now().year),
                model_aim = str(report_params['model_aim']),
                model_name = str(report_params['model_name']),
                zakazchik = str(report_params['zakazchik']),
                high_level_department = str(report_params['high_level_department']),
                ds_name = str(report_params['ds_name']),
                
                train_period = self.train_period,
                test_period = self.test_period,
                full_period = self.full_period,
                train_period_80 = self.train_period_80,
                valid_period = self.valid_period,
                
                target_descr = str(report_params['target_descr']),
                non_target_descr = str(report_params['non_target_descr']),
                
                count_train = str(self.count_train),
                count_test = str(self.count_test),
                count_full = str(self.count_full),
                count_train_80 = str(self.count_train_80),
                count_valid = str(self.count_valid),
                
                train_part_perc = '{:.2f}'.format(self.train_part_perc),
                test_part_perc = '{:.2f}'.format(self.test_part_perc),
                train_part_perc_80 = '{:.2f}'.format(self.train_part_perc_80),
                valid_part_perc = '{:.2f}'.format(self.valid_part_perc),
                full_part_perc = str(100.0),
                
                train_target_cnt = str(int(self.train_target_cnt)),
                test_target_cnt = str(int(self.test_target_cnt)),
                full_target_cnt = str(int(self.full_target_cnt)),
                train_target_cnt_80 = str(int(self.train_target_cnt_80)),
                valid_target_cnt = str(int(self.valid_target_cnt)),
                
                train_nontarget_cnt = str(int(self.train_nontarget_cnt)),
                test_nontarget_cnt = str(int(self.test_nontarget_cnt)),
                full_nontarget_cnt = str(int(self.full_nontarget_cnt)),
                train_nontarget_cnt_80 = str(int(self.train_nontarget_cnt_80)),
                valid_nontarget_cnt = str(int(self.valid_nontarget_cnt)),
                
                train_target_perc = '{:.2f}'.format(self.train_target_perc),
                test_target_perc = '{:.2f}'.format(self.test_target_perc),
                full_target_perc = '{:.2f}'.format(self.full_target_perc),
                train_target_perc_80 = '{:.2f}'.format(self.train_target_perc_80),
                valid_target_perc = '{:.2f}'.format(self.valid_target_perc),
                
                train_AUC_full = '{:.2f}'.format(self.train_AUC_full),
                test_AUC_full = '{:.2f}'.format(self.test_AUC_full),
                train_AUC_80 = '{:.2f}'.format(self.train_AUC_80),
                valid_AUC = '{:.2f}'.format(self.valid_AUC),
                test_AUC = '{:.2f}'.format(self.test_AUC),
                
                train_GINI_full = '{:.2f}'.format(self.train_GINI_full),
                test_GINI_full = '{:.2f}'.format(self.test_GINI_full),
                train_GINI_80 = '{:.2f}'.format(self.train_GINI_80),
                valid_GINI = '{:.2f}'.format(self.valid_GINI),
                test_GINI = '{:.2f}'.format(self.test_GINI),
                
                train_precision_full = '{:.2f}'.format(self.train_precision_full * 100),
                test_precision_full = '{:.2f}'.format(self.test_precision_full * 100),
                train_precision_80 = '{:.2f}'.format(self.train_precision_80 * 100),
                valid_precision = '{:.2f}'.format(self.valid_precision * 100),
                test_precision = '{:.2f}'.format(self.test_precision * 100),
                
                train_recall_full = '{:.2f}'.format(self.train_recall_full * 100),
                test_recall_full = '{:.2f}'.format(self.test_recall_full * 100),
                train_recall_80 = '{:.2f}'.format(self.train_recall_80 * 100),
                valid_recall = '{:.2f}'.format(self.valid_recall * 100),
                test_recall = '{:.2f}'.format(self.test_recall * 100),
                
                train_F1_full = '{:.2f}'.format(self.train_F1_full * 100),
                test_F1_full = '{:.2f}'.format(self.test_F1_full * 100),
                train_F1_80 = '{:.2f}'.format(self.train_F1_80 * 100),
                valid_F1 = '{:.2f}'.format(self.valid_F1 * 100),
                test_F1 = '{:.2f}'.format(self.test_F1 * 100),
                
                F1_thresh_full = '{:.2f}'.format(self.F1_thresh_full),
                F1_thresh = '{:.2f}'.format(self.F1_thresh),
                
                train_bins_full = np.round(self.train_bins_full, 3),
                test_bins_full = np.round(self.test_bins_full, 3),
                train_bins = np.round(self.train_bins, 3),
                valid_bins = np.round(self.valid_bins, 3),
                test_bins = np.round(self.test_bins, 3),
                
                interpretation_imgs = self.interpret_imgs,
                
                full_train_automl_time = "{:.3f} часов ({} сек.)".format(self.full_train_automl_time / 3600, int(self.full_train_automl_time)),
                full_train_automl_prediction_time = "{:.3f} часов ({} сек.)".format(self.full_train_automl_prediction_time / 3600, int(self.full_train_automl_prediction_time)),
                OOS_train_automl_time = "{:.3f} часов ({} сек.)".format(self.OOS_train_automl_time / 3600, int(self.OOS_train_automl_time)),
                OOS_train_automl_prediction_OOS_time = "{:.3f} часов ({} сек.)".format(self.OOS_train_automl_prediction_OOS_time / 3600, int(self.OOS_train_automl_prediction_OOS_time)),
                OOS_train_automl_prediction_OOT_time = "{:.3f} часов ({} сек.)".format(self.OOS_train_automl_prediction_OOT_time / 3600, int(self.OOS_train_automl_prediction_OOT_time))
            ))

    def generate_report(self,
                        report_params):
        if not os.path.exists(report_params['output_path']):
            os.mkdir(report_params['output_path'])
        
        copyfile(os.path.join(os.path.dirname(__file__), 'shap.js'), os.path.join(report_params['output_path'], 'shap.js'))     
        self.train_OOS_automl(report_params)
        self.calculate_values(report_params)
        self.plot_graphs(report_params)
        self.generate_interpret_imgs(report_params)
        self.write_report_to_file(report_params)
        print('Successfully wrote {}.'.format(os.path.join(report_params['output_path'], 'report.html')))

