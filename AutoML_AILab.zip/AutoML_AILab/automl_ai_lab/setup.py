import platform
import subprocess

from setuptools import setup, find_packages

if platform.system() == 'Linux':
    bashCommand = 'pip install --user -U numpy scipy==1.2.0 pandas scikit-learn lightgbm==2.3.0 hyperopt psutil shap setuptools==40.5.0 xgboost==0.90 joblib torch==1.0.0 gensim==3.6.0 pymystem3 tqdm seaborn jinja2'
    print(bashCommand)
    process = subprocess.Popen(bashCommand.split(), stdout = subprocess.PIPE)
    output, error = process.communicate()
    if output:
        print(output.decode('utf-8'))
    if error: 
        print(error.decode('utf-8'))

# if platform.system() == 'Windows':
#     copy2('C:\\Users\\'  + os.getlogin() + '\\AppData\\Roaming\\Python\\xgboost\\xgboost.dll', 'C:\\Users\\' + os.getlogin() + '\\AppData\\Roaming\\Python\\Python36\\site-packages\\xgboost\\')

def get_version():
    with open('sber_ailab_automl/__init__.py') as f:
        for line in f:
            if line.startswith('__version__'):
                break
        return line.split('= ')[1].strip()[1:-1]

setup(name='sber_ailab_automl',
      version=get_version(),
      description='Sberbank version of AutoML (Sberbank AI Lab)',
      classifiers=[
        'Development Status :: 3 - Alpha',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.6',
        'Topic :: AutoML',
      ],
      keywords='automl',
      author='Alexander Ryzhkov, Anton Vakhrushev',
      author_email='amryzhkov@sberbank.ru, agvakhrushev@sberbank.ru',
      license='MIT',
      packages=find_packages(),
      entry_points = {
        'console_scripts': ['saa-train=sber_ailab_automl.command_line:train',
                            'saa-predict=sber_ailab_automl.command_line:predict'],
      },
      include_package_data=True)
